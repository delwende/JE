<?php $__env->startSection('index_body'); ?>
<div class="ed_pagetitle">
<div class="ed_img_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-4 col-sm-6">
				<div class="page_title">
					<h2>Ouvrez un Cour</h2>
				</div>
			</div>
			<div class="col-lg-6 col-md-8 col-sm-6">
				<ul class="breadcrumb">
					<li><a href="<?php echo e(url('home')); ?>">Accueil</a></li>
					<li><i class="fa fa-chevron-left"></i></li>
					<li><a href="#">Ouvrez un cours</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<!--Breadcrumb end-->
<div class="ed_transprentbg ed_toppadder80 ed_bottompadder80">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-lg-offset-3 col-md-offset-3">
				<div class="ed_teacher_div">
					<div class="ed_heading_top">
						<h3>Ouvrez un cours</h3>
					</div>
					<?php echo Form::open(['route'=>'create_course.store','class'=>'ed_contact_form ed_toppadder40', 'files'=>'true']); ?> 
						<div class="form-group <?php echo $errors->has('name')?'has-error':''; ?>">
							<?php echo Form::text('name',null,['class'=>'form-control', 'placeholder'=>'Titre du cours']); ?> <?php echo $errors->first('name', '<small class="help-block">:message</small>'); ?>

						</div>
						<div class="form-group <?php echo $errors->has('description')?'has-error':''; ?>">
							<?php echo Form::textarea('description', null,['class'=>'form-control','placeholder'=>'Description du Cours']); ?>

                            <?php echo $errors->first('description','<small class="help-block">:message</small>'); ?>

						</div>
							<div class="form-group <?php echo $errors->has('category')?'has-error':''; ?>">
							<?php echo Form::select('category' ,array(
                            'Choisir la Catégorie du cours',
                            '1'=>'Développement Web',
                            '2'=>'Développement mobile',
                            '3'=>'Business management',
                            '4'=>'Langues',
                            '5'=>'Motivation'
                            
                            ),['class'=>'form-control','id'=>'selectCat']); ?>

                            <?php echo $errors->first('category','<small class="help-block">:message</small>'); ?>

						</div>
                    <div class="form-group <?php echo $errors->has('price')?'has-error':''; ?>">
							<?php echo Form::text('price','Gratuit',['class'=>'form-control','placeholder'=>'price']); ?>

                            <?php echo $errors->first('price','<small class="help-block">:message</small>'); ?>

						</div>
                    <div class="form-group <?php echo $errors->has('sale')?'has-error':''; ?>">
							<?php echo Form::number('sale',null,['class'=>'form-control','placeholder'=>'Prix Promo']); ?>

                            <?php echo $errors->first('sale','<small class="help-block">:message</small>'); ?>

						</div>
                    <div class="form-group <?php echo $errors->has('langue')?'has-error':''; ?>">
                    
							<?php echo Form::select('langue', array(
                            'Langue du cours',
                            'Moore'=>'Moore',
                            'Dioula'=>'Dioula',
                            'Wolof'=>'Wolof',
                            'Swahili'=>'Swahili',
                            'Fula'=>'Fula',
                            'Yoruba'=>'Yoruba',
                            'Twi'=>'twi'
                            
                            ),['class'=>'form-control','id'=>'selectLangue']); ?>

                            <?php echo $errors->first('langue','<small class="help-block">:message</small>'); ?>

						</div>
                    <div class="form-group <?php echo $errors->has('duration')?'has-error':''; ?>">
							<?php echo Form::number('duration','Gratuit',['class'=>'form-control','placeholder'=>'Durée du cours en semaines']); ?>

                            <?php echo $errors->first('duration','<small class="help-block">:message</small>'); ?>

						</div>
                    <div class="form-group <?php echo $errors->has('image')?'has-error':''; ?>">
                        <?php echo Form::label('imageCourse','Image du Cours'); ?>

							<?php echo Form::file('image',['class'=>'form-control','placeholder'=>'image du cours','id'=>'imageCourse']); ?>

                            <?php echo $errors->first('image','<small class="help-block">:message</small>'); ?>

						</div>
                    <div class="form-group <?php echo $errors->has('video[]')?'has-error':''; ?>">
                        
                        <?php echo Form::label('CourseVideo', 'Les Vidéos de votre Cours'); ?>

                        <div class="lesson_container">
                        <div>
                        <?php echo Form::text('lesson_title[]',null,['class'=>'form-control','placeholder'=>'Titre de la Lesson']); ?>

                      <?php echo Form::file('video[]',['class'=>'form-control','id'=>'CourseVideo']); ?>

                      <?php echo $errors->first('video[]','<small class="help-block">:message</small>'); ?>

                            </div>
                        <div class="row"></div>
                            <br>
                        <?php echo Form::button('Ajouter une lesson &nbsp;<i class="fa fa-plus" aria-hidden="true"></i>
',['class'=>'btn ed_btn ed_orange pull-left','id'=>'add_lesson']); ?>

                            
                            </div>
                        <br>
                            
                   </div>
                    <?php echo Form::hidden('prof_id',$prof_id); ?>

						<?php echo Form::submit('Enregistrer',['class'=>'btn ed_btn ed_orange pull-right']); ?>

                    <?php echo Form::close(); ?>

					
					
				</div>
			</div>
		</div>
	</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script>
   $(document).ready(function()
                    {
       var wrapper=$(".lesson_container");
       var add=$("#add_lesson");
       $(add).click(function(e)
                   {
           e.preventDefault();
           $(wrapper).append('<br> <br><br><div><label for="newvideo">Ajouter une Video</label><input type="text" name="lesson_title[]" value="" class="form-control", placeholder="Titre de la lesson"  id="newvideo" required><input type="file" name="video[]" class="form-control" required><div></div><br><button href="#" class="btn-primary" id="delete">Suprimer &nbsp;<i class="fa fa-trash-o" aria-hidden="true"></i></button></div>')
           
       });
       $(wrapper).on("click","#delete", function(e){
         e.preventDefault();
           $(this).parent('div').remove();
       });
       
   });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('checkout-template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>