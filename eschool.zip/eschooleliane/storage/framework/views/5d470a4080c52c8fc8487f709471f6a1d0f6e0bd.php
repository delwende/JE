<?php $__env->startSection('index_body'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Changer de Mot de Passe</div>
                <div class="panel-body">
                
                    <?php echo Form:: open(['route'=>'password.email','class'=>'ed_contact_form ed_toppadder40']); ?>

                    
                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <?php echo Form::email('email',old('email'), ['class'=>'form-control','placeholder'=>'Email']); ?>

                            <?php echo $errors->first('email','<small class="help-block">:message</small>'); ?>

                                
                        
                        </div>

                        <div class="form-group">
                            
                             <?php echo Form::submit('Envoyer', ['class'=>'btn btn-primary']); ?>

                                
                        </div>
                    <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pass-template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>