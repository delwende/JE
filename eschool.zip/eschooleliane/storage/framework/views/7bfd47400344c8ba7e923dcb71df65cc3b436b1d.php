<?php $__env->startSection('index_body'); ?>
<div class="ed_pagetitle">
<div class="ed_img_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-4 col-sm-6">
				<div class="page_title">
					<h2>S'inscrire</h2>
				</div>
			</div>
			<div class="col-lg-6 col-md-8 col-sm-6">
				<ul class="breadcrumb">
					<li><a href="<?php echo e(url('index2')); ?>">Accueil</a></li>
					<li><i class="fa fa-chevron-left"></i></li>
					<li><a href="#">S'inscrire</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<!--Breadcrumb end-->
<div class="ed_transprentbg ed_toppadder80 ed_bottompadder80">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-lg-offset-3 col-md-offset-3">
				<div class="ed_teacher_div">
					<div class="ed_heading_top">
						<h3>S'inscrire</h3>
					</div>
					<?php echo Form:: open(['route'=>'register','class'=>'ed_contact_form ed_toppadder40', 'files'=>'true']); ?> 
						<div class="form-group <?php echo $errors->has('name')?'has-error':''; ?>">
							<?php echo Form::text('name',null,['class'=>'form-control', 'placeholder'=>'Pseudonyme']); ?> <?php echo $errors->first('name', '<small class="help-block">:message</small>'); ?>

						</div>
						<div class="form-group <?php echo $errors->has('email')?'has-error':''; ?>">
							<?php echo Form::email('email', null,['class'=>'form-control','placeholder'=>'Email']); ?>

                            <?php echo $errors->first('email','<small class="help-block">:message</small>'); ?>

						</div>
						<div class="form-group <?php echo $errors->has('password')?'has-error':''; ?>">
							<?php echo Form::password('password',['class'=>'form-control', 'placeholder'=>'Mot de Passe']); ?>

                            <?php echo $errors->first('password','<small class="help-block">:message</small>'); ?>

						</div>
						<div class="form-group">
							<?php echo Form::password('password_confirmation',['class'=>'form-control','placeholder'=>'Confirmer le mot de passe']); ?>

						</div>
                    <div class="form-group <?php echo $errors->has('image')?'has-error':''; ?>">
                      <?php echo Form::file('image',['class'=>'form-control']); ?>

                      <?php echo $errors->first('image','<small class="help-block">:message</small>'); ?>

             
                   </div>
						<?php echo Form::submit('Enregistrer',['class'=>'btn ed_btn ed_orange pull-right']); ?>

                    <?php echo Form::close(); ?>

					
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login-template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>