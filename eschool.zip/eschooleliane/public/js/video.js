$(function() {
    $("#playlist li").on("click", function() {
        $("#videoarea").attr({
            "src": $(this).attr("movieurl"),
            "poster": "",
            "autoplay": "autoplay"
        })
    })
    $("#videoarea").attr({
        "src": $("#playlist li").eq(0).attr("movieurl"),
        "poster": $("#playlist li").eq(0).attr("moviesposter")
    })
})
var len=$("#playlist li").length;
console.log("len"+len);
for(var i=1; i<= len;i++)
    {
        console.log("video_title_"+i);
        var j=1;
      document.getElementById("video_title_"+i).onclick = function() {
           
          console.log("checked_"+j);
          document.getElementById("checked_"+j).style.display='block';
          j+=1;
      }
    }


