<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\course_cat;
use App\enrollement;
class sideBarController extends Controller
{
    
    public function display($title)
    {
        $Courses=DB::table('courses')->join('courses_cat',function($join) use($title)
                                            {
                                                
                                                $join->on('courses.cat_id','=','courses_cat.id')->where('courses_cat.title',$title);
                                            })->paginate(18);
        $links=$Courses->links();
        if ($Courses->isEmpty())
        {
           $statu=" Aucun cour dans cette Catégorie";
            
            return view('course_sidebar')->with(compact('statu'));
            
            
        }
        else
        {
            
            return view('course_sidebar')->with(compact('Courses','links'));
        }
        
        
    }
    
    //
}
