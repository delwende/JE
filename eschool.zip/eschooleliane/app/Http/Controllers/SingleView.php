<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Course;
use App\lessons;
use App\User;
use App\enrollement;
use Illuminate\Support\Collection;
use Illuminate\Pagination\Paginator;
class SingleView extends Controller
{
    
    public function show($id)
        
    {
        /*=======================================================
        
          get course its students , its prof and its lessons
        ========================================================*/
        $course=Course::find($id);
        $lessons=lessons::where('course_id',$id)->orderBy('id','asc')->get();
        $students=DB::table('users')->join('enrolement', function($join) use($id)
                                           {
                                              $join->on('users.id','=','enrolement.student_id')->where('course_id',$id); 
                                           })->select('users.name','users.image','users.id')->paginate(15);
        $instructor=DB::table('users')->join('instructors','instructors.user_id','=','users.id')->join('courses',function($query) use($id){
            
            $query->on('courses.prof_id','=','instructors.id')->where('courses.id',$id);
        })->select('users.name','users.image','instructors.id','instructors.location')->get();
        
        /*===============================================================
        
          get students number , prof id and handle if enroled/Not students
          
           will also get related courses and popular courses
        =================================================================*/
        $students_number=0;
           
        // get related courses 
        $course_cat=$course->cat_id;
        
        
        
        $relatedCourses=Course::where('cat_id',$course_cat)->orderBy('id','asc')->limit(7)->get();
        
        $popularCourse=Course::latest()->limit(5)->get();
        
        //get
        
        foreach($instructor as $teacher)
                
            {
                $teacher_id=$teacher->id;
                
            }
        
        if($students->isEmpty())
        {
            $statu="Ce cours n'a aucun participant";
            
    return view('course_single')->with(compact('statu','students_number','lessons','course','instructor','teacher_id','relatedCourses','popularCourse'));
            
            
        }
        else
        {
            $links=$students->links();
            
            $students_number=count($students);
            
            
            $index=0;
            foreach($students as $eleve)
            {
                $students_id[$index]=$eleve->id;
                $index++;
            }
            
            return view('course_single')->with(compact('students_number','lessons','course','students','instructor','links','students_id','teacher_id','popularCourse','relatedCourses'));
        }
        
        
    }
    //
}
