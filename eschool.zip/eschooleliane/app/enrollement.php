<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class enrollement extends Model
{
    
    protected $table='enrolement';
    
    public $timestamps=false;
    //
}
