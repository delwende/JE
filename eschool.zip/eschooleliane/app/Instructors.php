<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Instructors extends Model
{
    
    protected $table='instructors';
    
    public $timestamps =false ;
    //
}
