<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class course_cat extends Model
{
    protected $table='courses_cat';
    
    public $timestamps=false;
    //
}
