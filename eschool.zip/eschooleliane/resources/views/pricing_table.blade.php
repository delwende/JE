<!DOCTYPE html>
<!-- 
Template Name: Educo
Version: 3.0.0
Author: 
Website: 
Purchase: 
-->
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<!--<![endif]-->

<!-- Begin Head -->
<head>
<meta charset="utf-8" />
<title>Educo Multipurpose Responsive HTML Template</title>
<meta content="width=device-width, initial-scale=1.0" name="viewport" />
<meta name="description"  content="Educo"/>
<meta name="keywords" content="Educo, html template, Education template" />
<meta name="author"  content="Kamleshyadav"/>
<meta name="MobileOptimized" content="320" />

<!--srart theme style -->
<link href="css/main.css" rel="stylesheet" type="text/css"/>
<!-- end theme style -->
<!-- favicon links -->
<link rel="shortcut icon" type="image/png" href="images/header/favicon.png" />
</head>
<body>
<!--Page main section start-->
<div id="educo_wrapper">
<!--Header start-->
<header id="ed_header_wrapper">
	<div class="ed_header_top">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12">
					<p>welcome to our new session of education</p>
					<div class="ed_info_wrapper">
						<a href="#" id="login_button">Login</a>
							<div id="login_one" class="ed_login_form">
								<h3>log in</h3>
								<form class="form">
									<div class="form-group">
										<label class="control-label">Email :</label>
										<input type="text" class="form-control" >
									</div>
									<div class="form-group">
										<label  class="control-label">Password :</label>
										<input type="password" class="form-control">
									</div>
									<div class="form-group">
										<button type="submit">login</button>
										<a href="signup.html">registration</a>	
									</div>
								</form>
							</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="ed_header_bottom">
		<div class="container">
			<div class="row">
				<div class="col-lg-2 col-md-2 col-sm-2">
					<div class="educo_logo"> <a href="index.html"><img src="images/header/Logo.png" alt="logo" /></a> </div>
				</div>
				<div class="col-lg-8 col-md-8 col-sm-8">
					<div class="edoco_menu_toggle navbar-toggle" data-toggle="collapse" data-target="#ed_menu">Menu <i class="fa fa-bars"></i>
					</div>
					<div class="edoco_menu">
						<ul class="collapse navbar-collapse" id="ed_menu">
							<li><a href="#">Home</a>
								<ul class="sub-menu">
									<li><a href="index.html">Home</a></li>
									<li><a href="index2.html">home-2</a></li>
								</ul>
							</li>
							<li><a href="about.html">about us</a></li>
							<li><a href="#">blog</a>
								<ul class="sub-menu">
									<li><a href="blog.html">blog-large</a></li>
									<li><a href="blog_med.html">blog-medium</a></li>
									<li><a href="blog_single.html">blog-single</a></li>
								</ul>
							</li>
							<li><a href="#">events</a>
								<ul class="sub-menu">
									<li><a href="events.html">all events</a></li>
									<li><a href="event_single.html">events-single</a></li>
								</ul>
							</li>
							<li><a href="#">courses</a>
								<ul class="sub-menu">
									<li><a href="courses.html">all courses</a></li>
									<li><a href="course_sidebar.html">course-sidebar</a></li>
									<li><a href="course_single.html">course-single</a></li>
									<li><a href="course_lesson.html">course-lesson</a></li>
								</ul>
							</li>
							<li><a href="#">Pages</a>
								<ul class="sub-menu">
									<li><a href="instructor.html">all instructor</a></li>
									<li><a href="instructor_dashboard.html">instructor dashboard</a></li>
									<li><a href="dashboard.html">student dashboard</a></li>
									<li><a href="become_teacher.html">Become teacher</a></li>
									<li><a href="pricing_table.html">pricing table</a></li>
									<li><a href="cart.html">cart</a></li>
									<li><a href="checkout.html">checkout</a></li>
									<li><a href="purchase_course.html">purchase course</a></li>
									<li><a href="not_found.html">404 error</a></li>
								</ul>
							</li>
							<li><a href="contact.html">Contact</a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2">
					<div class="educo_call"><i class="fa fa-phone"></i><a href="#">1-220-090</a></div>
				</div>
			</div>
		</div>
    </div>
</header>
<!--header end -->
<!--Breadcrumb start-->
<div class="ed_pagetitle">
<div class="ed_img_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-4 col-sm-6">
				<div class="page_title">
					<h2>pricing table</h2>
				</div>
			</div>
			<div class="col-lg-6 col-md-8 col-sm-6">
				<ul class="breadcrumb">
					<li><a href="index.html">home</a></li>
					<li><i class="fa fa-chevron-left"></i></li>
					<li><a href="pricing_table.html">pricing table</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<!--Breadcrumb end-->
<!-- pricing table section start -->
<div class="ed_transprentbg ed_toppadder80 ed_bottompadder50">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="ed_heading_top ed_bottompadder50">
					<h3>3 column pricing table</h3>
				</div>
			</div>
		</div>
		<div class="ed_pricing_table_wrapper ed_bottompadder50">
		<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
			<div class="ed_pricing_table">
				<div class="ed_pricing_heading">
					<h2>starter</h2>
					<div class="ed_table_price">
						<p><small>$ </small>29<span> /day</span></p>
					</div>
				</div>
				<ul>
					<li>One Day Trial</li>
					<li>Limited Courses</li>
					<li>Free 3 Lessons</li>
					<li>No Supporter</li>
					<li>No Ebook</li>
					<li>No Tutorial</li>
					<li>Limited Registered User</li>
				</ul>
				<div class="ed_pricing_tabel_footer">
					<a href="#" class="btn ed_btn ed_green">purchase now</a>
				</div>
			</div>
		</div>
		<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
			<div class="ed_pricing_table">
				<div class="ed_pricing_heading">
					<h2>basic</h2>
					<div class="ed_table_price">
						<p class="ed_price_dollar"><small>$ </small>35<span> /day</span></p>
					</div>
				</div>
				<ul>
					<li>One Day Standard Access</li>
					<li>Limited Courses</li>
					<li>300+ Lessons</li>
					<li>Random Supporter</li>
					<li>View Only Ebook</li>
					<li>Standard Tutorials</li>
					<li>Unlimited Registered User</li>
				</ul>
				<div class="ed_pricing_tabel_footer">
					<a href="#" class="btn ed_btn ed_green">purchase now</a>
				</div>
			</div>
		</div>
		<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
			<div class="ed_pricing_table">
				<div class="ed_pricing_heading">
					<h2>premium</h2>
					<div class="ed_table_price">
						<p class="ed_price_dollar"><small>$ </small>40<span> /yr</span></p>
					</div>
				</div>
				<ul>
					<li>Life Time Access</li>
					<li>Unlimited All Courses</li>
					<li>3000+ Lessons & Growing</li>
					<li>Free Supporter</li>
					<li>Free Ebook Downloads</li>
					<li>Premium Tutorials</li>
					<li>Unlimited Registered User</li>
				</ul>
				<div class="ed_pricing_tabel_footer">
					<a href="#" class="btn ed_btn ed_green">purchase now</a>
				</div>
			</div>
		</div>
		</div>
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="ed_heading_top ed_bottompadder50">
					<h3>4 column pricing table</h3>
				</div>
			</div>
		</div>
		<div class="ed_pricing_table_wrapper_second">
		<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
			<div class="ed_pricing_table">
				<div class="ed_pricing_heading">
					<div class="ed_table_price">
						<p class="ed_price_dollar"><small>$ </small>29<span> /day</span></p>
					</div>
					<h2>starter</h2>
				</div>
				<ul>
					<li>One Day Trial</li>
					<li>Limited Courses</li>
					<li>Free 3 Lessons</li>
					<li>No Supporter</li>
					<li>No Ebook</li>
					<li>No Tutorial</li>
					<li>Limited Registered User</li>
				</ul>
				<div class="ed_pricing_tabel_footer">
					<a href="#" class="btn ed_btn ed_orange">purchase now</a>
				</div>
			</div>
		</div>
		<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
			<div class="ed_pricing_table">
				<div class="ed_pricing_heading">
					<div class="ed_table_price">
						<p class="ed_price_dollar"><small>$ </small>35<span> /day</span></p>
					</div>
					<h2>basic</h2>
				</div>
				<ul>
					<li>One Day Standard Access</li>
					<li>Limited Courses</li>
					<li>300+ Lessons</li>
					<li>Random Supporter</li>
					<li>View Only Ebook</li>
					<li>Standard Tutorials</li>
					<li>Unlimited Registered User</li>
				</ul>
				<div class="ed_pricing_tabel_footer">
					<a href="#" class="btn ed_btn ed_orange">purchase now</a>
				</div>
			</div>
		</div>
		<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
			<div class="ed_pricing_table">
				<div class="ed_pricing_heading">
					<div class="ed_table_price">
						<p class="ed_price_dollar"><small>$ </small>40<span> /yr</span></p>
					</div>
					<h2>premium</h2>
				</div>
				<ul>
					<li>One year premium Access</li>
					<li>Unlimited Courses</li>
					<li>1000+ Lessons & Growing</li>
					<li>random Supporter</li>
					<li>Free Ebook Downloads</li>
					<li>Premium Tutorials</li>
					<li>Unlimited Registered User</li>
				</ul>
				<div class="ed_pricing_tabel_footer">
					<a href="#" class="btn ed_btn ed_orange">purchase now</a>
				</div>
			</div>
		</div>
		<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
			<div class="ed_pricing_table">
				<div class="ed_pricing_heading">
					<div class="ed_table_price">
						<p class="ed_price_dollar"><small>$ </small>45<span> /yr</span></p>
					</div>
					<h2>advance</h2>
				</div>
				<ul>
					<li>Life Time Access</li>
					<li>Unlimited All Courses</li>
					<li>3000+ Lessons & Growing</li>
					<li>Free Supporter</li>
					<li>Free Ebook Downloads</li>
					<li>advance Tutorials</li>
					<li>Unlimited Registered User</li>
				</ul>
				<div class="ed_pricing_tabel_footer">
					<a href="#" class="btn ed_btn ed_orange">purchase now</a>
				</div>
			</div>
		</div>
		</div>
    </div><!-- /.container -->
</div>
<!-- pricing table section end -->
<!--Newsletter Section six start-->
<div class="ed_newsletter_section">
<div class="ed_img_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12">
				<div class="row">
					<div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
						<div class="ed_newsletter_section_heading">
							<h4>Let us inform you about everything important directly.</h4>
						</div>
					</div>
					<div class="col-lg-5 col-md-5 col-sm-6 col-xs-6 col-lg-offset-0 col-md-offset-0 col-sm-offset-3 col-xs-offset-3">
						<div class="row">
							<div class="ed_newsletter_section_form">
								<form class="form">
									<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
										<input class="form-control" type="text" placeholder="Newsletter Email" />
									</div>
									<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
										<button class="btn ed_btn ed_green">confirm</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
        </div>
	</div>
</div>
<!--Newsletter Section six end-->
<!--Footer Top section start-->
<div class="ed_footer_wrapper">
	<div class="ed_footer_top">
		<div class="container">
			<div class="row">
				<div class="col-lg-4 col-md-4 col-sm-12">
					<div class="widget text-widget">
						<p><a href="index.html"><img src="images/footer/F_Logo.png" alt="Footer Logo" /></a></p>
						<p>Edution is an outstanding PSD template targeting educational institutions, helping them establish strong identity on the internet without any real developing knowledge.
						</p>
						<div class="ed_sociallink">
							<ul>
								<li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
								<li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Google+"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
								<li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
								<li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Linkedin"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
								<li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Whatsapp"><i class="fa fa-whatsapp" aria-hidden="true"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-12">
					<div class="widget text-widget">
						<h4 class="widget-title">find us</h4>
						<p><i class="fa fa-safari"></i>Wimbledon Street 42a, 45290 Wimbledon, <br/>United Kingdom</p>
						<p><i class="fa fa-envelope-o"></i><a href="#">info@edutioncollege.gov.co.uk</a> <a href="#">public@edutioncollege.gov.co.uk</a></p>
						<p><i class="fa fa-phone"></i> 1-220-090-080</p>
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-12">
					<div class="widget text-widget">
						<h4 class="widget-title">social media</h4>
						<p><strong>@education </strong> How many students do you educate monthly? Open <a href=""> http://t.co/KFDdzLSD9</a><br/>2 days ago</p>
						
						<p><strong>@educationUK </strong> Web Design that works. Have a look at this masterpiece. <a href="">http://t.co/9j8DH93zrO</a><br/>5 days ago</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--Footer Top section end-->
<!--Footer Bottom section start-->
<div class="ed_footer_bottom">
	<div class="container">
		<div class="col-lg-12 col-md-12 col-sm-12">
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
				<div class="ed_copy_right">
					<p>&copy; Copyright 2017, All Rights Reserved, <a href="#">EDUCO</a></p>
				</div>
			</div>
			<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
				<div class="ed_footer_menu">
						<ul>
							<li><a href="index.html">home</a></li>
							<li><a href="private_policy.html">private policy</a></li>
							<li><a href="about.html">about</a></li>
							<li><a href="contact.html">contact us</a></li>
						</ul>
				</div>
			</div>
		</div>
		</div>
	</div>
</div>
<!--Footer Bottom section end-->
</div>
<!--Page main section end-->
<!--main js file start--> 
<script type="text/javascript" src="js/jquery-1.12.2.js"></script> 
<script type="text/javascript" src="js/bootstrap.js"></script> 
<script type="text/javascript" src="js/modernizr.js"></script> 
<script type="text/javascript" src="js/owl.carousel.js"></script>
<script type="text/javascript" src="js/smooth-scroll.js"></script> 
<script type="text/javascript" src="js/plugins/revel/jquery.themepunch.tools.min.js"></script>
<script type="text/javascript" src="js/plugins/revel/jquery.themepunch.revolution.min.js"></script>
<script type="text/javascript" src="js/plugins/revel/revolution.extension.layeranimation.min.js"></script>
<script type="text/javascript" src="js/plugins/revel/revolution.extension.navigation.min.js"></script>
<script type="text/javascript" src="js/plugins/revel/revolution.extension.slideanims.min.js"></script>
<script type="text/javascript" src="js/plugins/countto/jquery.countTo.js"></script>
<script type="text/javascript" src="js/plugins/countto/jquery.appear.js"></script>
<script type="text/javascript" src="js/custom.js"></script> 
<!--main js file end-->
</body>
</html>