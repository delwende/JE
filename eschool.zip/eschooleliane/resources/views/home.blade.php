@extends('template')
<!--Slider form end-->

@section('index_body')
<!-- Most recomended Courses start -->
<div class="ed_transprentbg ed_toppadder80 ed_bottompadder80">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="ed_heading_top ed_bottompadder50 ed_toppadder50">
					<h3>Trouver le cours adéquat</h3>
				</div>
			</div>
            
            
			<div class="ed_mostrecomeded_course_slider">
			
                @foreach($courses as $course)
                
                @if($loop->index==$i)
                <?php 
                $id=$i+1;
                    $user_0=DB::table('enrolement')->where('course_id','=',$id)->count();
                ?>
				<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    
					<div class="ed_mostrecomeded_course">
						<div class="ed_item_img">
				<img src="{{asset('images/'.$course->course_image)}}" alt="item1" class="img-responsive">
						</div>
						<div class="ed_item_description ed_most_recomended_data">
							<h4><a href="{{url('course_single/'.$id)}}">{{$course->course_title}} </a><span>£{{$course->price}}</span></h4>
							<div class="row">
								<div class="ed_rating">
									<div class="col-lg-6 col-md-6 col-sm-7 col-xs-7">
										<div class="row">
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
												<div class="ed_stardiv">
													<div class="star-rating"><span style="width:80%;"></span></div>
												</div>
											</div>
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
												<div class="row">
													<p>(5 review)</p>
												</div>
											</div>
										</div>
									</div>
									<div class="col-lg-6 col-md-6 col-sm-5 col-xs-5">
										<div class="ed_views">
										<i class="fa fa-users"></i>
										<span>{!!$user_0!!} étudiants</span>
										</div>
									</div>
								</div>
							</div>
							<div class="course_detail">
								<div class="course_faculty">
									<img src="{{asset('images/'.$course->image)}}" alt=""> <a href="{{url('instructor_dashboard')}}">{{$course->name}}</a>
								</div>
							</div>
							<p>{!!$course->description!!}</p>
							<a href="{{url('course_single/'.$id)}}" class="ed_getinvolved">Participer <i class="fa fa-long-arrow-right"></i></a>
						</div>
					</div>
                    
                    
				</div>
                
                    
                    @elseif($loop->index==$i+1)
				<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    
                    
                    <?php 
                    $i+=1;
                    
                
                  $id=$i+1;
                    $user=DB::table('enrolement')->where('course_id','=',$id)->count();
                
                    ?>
					<div class="ed_mostrecomeded_course">
						<div class="ed_item_img">
				<img src="{{asset('images/'.$course->course_image)}}" alt="item1" class="img-responsive">
						</div>
						<div class="ed_item_description ed_most_recomended_data">
							<h4><a href="{{url('course_single/'.$id)}}">{{$course->course_title}} </a><span>£{{$course->price}}</span></h4>
							<div class="row">
								<div class="ed_rating">
									<div class="col-lg-6 col-md-6 col-sm-7 col-xs-7">
										<div class="row">
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
												<div class="ed_stardiv">
													<div class="star-rating"><span style="width:80%;"></span></div>
												</div>
											</div>
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
												<div class="row">
													<p>(5 review) </p>
												</div>
											</div>
										</div>
									</div>
									<div class="col-lg-6 col-md-6 col-sm-5 col-xs-5">
										<div class="ed_views">
										<i class="fa fa-users"></i>
										<span>{!!$user!!} étudiants</span>
										</div>
									</div>
								</div>
							</div>
							<div class="course_detail">
								<div class="course_faculty">
									<img src="{{asset('images/'.$course->image)}}" alt=""> <a href="{{url('instructor_dashboard')}}">{{$course->name}}</a>
								</div>
							</div>
							<p>{!!$course->description!!}</p>
							<a href="{{url('course_single/'.$id)}}" class="ed_getinvolved">Participer <i class="fa fa-long-arrow-right"></i></a>
						</div>
					</div>
                    
                    
				</div>
                 @endif
                    
                @endforeach   
               {{$links}}
			</div>
            
                    
                    
				<!--<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
					<div class="ed_mostrecomeded_course">
						<div class="ed_item_img">
							<img src="http://placehold.it/330X330" alt="item1" class="img-responsive">
						</div>
						<div class="ed_item_description ed_most_recomended_data">
							<h4><a href="{{url('course_single')}}">Javascript Camp</a><span>£60</span></h4>
							<div class="row">
								<div class="ed_rating">
									<div class="col-lg-6 col-md-6 col-sm-7 col-xs-7">
										<div class="row">
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
												<div class="ed_stardiv">
													<div class="star-rating"><span style="width:80%;"></span></div>
												</div>
											</div>
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
												<div class="row">
													<p>(10 review)</p>
												</div>
											</div>
										</div>
									</div>
									<div class="col-lg-6 col-md-6 col-sm-5 col-xs-5">
										<div class="ed_views">
										<i class="fa fa-users"></i>
										<span>55 étudiants</span>
										</div>
									</div>
								</div>
							</div>
							<div class="course_detail">
								<div class="course_faculty">
									<img src="http://placehold.it/32X32" alt=""> <a href="{{url('instructor_dashboard')}}"> FRANK PASCAL</a>
								</div>
							</div>
							<p>Project-Based Learning is a flexible tool for framing given academic standards into curriculum flexible tool for framing.</p>
							<a href="{{url('course_single')}}" class="ed_getinvolved">Participer <i class="fa fa-long-arrow-right"></i></a>
						</div>
					</div>
				</div>-->
               
		</div>
    </div><!-- /.container -->
</div>
<!-- Most recomended Courses end -->
<!--counter section start -->
<div class="ed_graysection ed_toppadder90 ed_bottompadder90">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="ed_heading_top ed_bottompadder50">
					<h3>Pourquoi devriez-vous nous choisir </h3>
				</div>
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="ed_counter_wrapper">
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
						<div class="ed_counter">
							<h2 class="timer" data-from="0" data-to="2600" data-speed="5000"></h2>
							<h4>Nombre de gradués</h4>
							<p>Throughout these year we have done amazing work with 250 students..</p>
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
						<div class="ed_counter">
							<h2 class="timer" data-from="0" data-to="5900" data-speed="5000"></h2>
							<h4>Competitions gagnées</h4>
							<p>Only competitions were the ones in the back of the magazines you find..</p>
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
						<div class="ed_counter">
							<h2 class="timer" data-from="0" data-to="8400" data-speed="5000"></h2>
							<h4>Classes visitées</h4>
							<p>Can how you setup your classroom impact how students think...</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--counter section end -->
<!--video_section Section three start -->
<div class="ed_parallax_section">
<div class="ed_img_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-12">
				<div class="ed_video_section">
					<div class="embed-responsive embed-responsive-16by9">
						<div class="ed_video">
							<img src="http://placehold.it/544X334" style="cursor:pointer"  alt="1" />
							<div class="ed_img_overlay">
								<a href="#"><i class="fa fa-chevron-right"></i></a>
							</div>
						</div>
						<iframe id="educo_video" class="embed-responsive-item" src="https://www.youtube.com/embed/8mb-0qbq984" allowfullscreen></iframe>
					</div>
				</div>
			</div>
			<div class="col-lg-6 col-md-6 col-sm-12">
				<div class="ed_video_section_discription">
					<h4>Daily life of studying at Educo</h4>
					<p>Nam cursus imperdiet elit. Fusce sollicitudin eget nulla in condimentum. Nullam dignissim id magna non tempus. Vivamus molestie nulla nec pharetra dignissim. Suspendisse auctor nisi et neque vehicula pulvinar. Quisque quis tempus magna. Quisque sed luctus nunc sapien.</p>
					<span><a href="#" class="btn ed_btn ed_orange">Voir plus</a></span>
				</div>
			</div>
		</div>
	</div>
</div>
<!--video_section Section three end -->
<!--Our expertise section one start -->
<div class="ed_graysection ed_toppadder80">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="ed_heading_top">
					<h3>Nos domaines d'expertise </h3>
				</div>
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="ed_populer_areas_slider">
					<div class="owl-carousel owl-theme">
						<div class="item">
							<div class="ed_item_img">
								<img src="http://placehold.it/263X263" alt="item1" class="img-responsive">
							</div>
							<div class="ed_item_description">
								<h4>Vocational Counselling</h4>
								<p>Vocational counselling is a career on people who need to find a job. Pretty obvious, obvious right?</p>
								<a href="#" class="ed_getinvolved">Participer <i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div>
						<div class="item">
							<div class="ed_item_img">
								<img src="http://placehold.it/263X263" alt="item2" class="img-responsive">
							</div>
							<div class="ed_item_description">
								<h4>Elementary School</h4>
								<p>Vocational counselling is a career on people who need to find a job. Pretty obvious, obvious right?</p>
								<a href="#" class="ed_getinvolved">Participer<i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div>
						<div class="item">
							<div class="ed_item_img">
								<img src="http://placehold.it/263X263" alt="item3" class="img-responsive">
							</div>
							<div class="ed_item_description">
								<h4>Student Guidance</h4>
								<p>Vocational counselling is a career on people who need to find a job. Pretty obvious, obvious right?</p>
								<a href="#" class="ed_getinvolved">Participer <i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div>
						<div class="item">
							<div class="ed_item_img">
								<img src="http://placehold.it/263X263" alt="item4" class="img-responsive">
							</div>
							<div class="ed_item_description">
								<h4>Psychology Tests</h4>
								<p>Vocational counselling is a career on people who need to find a job. Pretty obvious, obvious right?</p>
								<a href="#" class="ed_getinvolved">Participer <i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div>
						<div class="item">
							<div class="ed_item_img">
								<img src="http://placehold.it/263X263" alt="item1" class="img-responsive">
							</div>
							<div class="ed_item_description">
								<h4>individual attention</h4>
								<p>Vocational counselling is a career on people who need to find a job. Pretty obvious, obvious right?</p>
								<a href="#" class="ed_getinvolved">Participer<i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div>
						<div class="item">
							<div class="ed_item_img">
								<img src="http://placehold.it/263X263" alt="item2" class="img-responsive">
							</div>
							<div class="ed_item_description">
								<h4>Peer Recognition</h4>
								<p>Vocational counselling is a career on people who need to find a job. Pretty obvious, obvious right?</p>
								<a href="#" class="ed_getinvolved">Participer <i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
    </div><!-- /.container -->
</div>
<!--Our expertise section one end -->
<!--Latest news Section start -->
<div class="ed_transprentbg ed_toppadder80 ed_bottompadder80">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="ed_heading_top ed_bottompadder50">
					<h3>Actualités</h3>
				</div>
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="ed_latest_newsslider">
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
						<div class="ed_latestnews">
							<h4>Officially the best</h4>
							<p>Just in case there is anyone looking for it, new expertise to our knowledge base to make you happy as well.</p>
							<a href="#">read more <i class="fa fa-long-arrow-right"></i></a>
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
						<div class="ed_latestnews">
							<h4>Redesigned website</h4>
							<p>Just in case there is anyone looking for it, new expertise to our knowledge base to make you happy as well.</p>
							<a href="#">Voir plus <i class="fa fa-long-arrow-right"></i></a>
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
						<div class="ed_latestnews">
							<h4>We are launching</h4>
							<p>Just in case there is anyone looking for it, new expertise to our knowledge base to make you happy as well.</p>
							<a href="#">Voir Plus <i class="fa fa-long-arrow-right"></i></a>
						</div>
					</div>
				</div>
			</div>
		</div>
    </div><!-- /.container -->
</div>
<!--Latest news Section end -->
<!--client section start -->
<div class="ed_graysection ed_toppadder80 ed_bottompadder80">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="ed_heading_top ed_bottompadder50">
					<h3>Nos Partenaires</h3>
				</div>
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="ed_clientslider">
					<div id="owl-demo5" class="owl-carousel owl-theme">
						<div class="item">
							<a href="#">
								<img src="http://placehold.it/100X40" alt="Partner Img" />
							</a>
						</div>
						<div class="item">
							<a href="#">
								<img src="http://placehold.it/100X40" alt="Partner Img" />
							</a>
						</div>
						<div class="item">
							<a href="#">
								<img src="http://placehold.it/100X40" alt="Partner Img" />
							</a>
						</div>
						<div class="item">
							<a href="#">
								<img src="http://placehold.it/100X40" alt="Partner Img" />
							</a>
						</div>
						<div class="item">
							<a href="#">
								<img src="http://placehold.it/100X40" alt="Partner Img" />
							</a>
						</div> 
						<div class="item">
							<a href="#">
								<img src="http://placehold.it/100X40" alt="Partner Img" />
							</a>
						</div>
						<div class="item">
							<a href="#">
								<img src="http://placehold.it/100X40" alt="Partner Img" />
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
    </div><!-- /.container -->
</div>
@endsection
