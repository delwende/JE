@extends('layouts.singleCourse-template')
<!--header end -->
<!--Breadcrumb start-->
@section('index_body')
<div class="ed_pagetitle">
<div class="ed_img_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-4 col-sm-6">
				<div class="page_title">
					<h2>Cours</h2>
				</div>
			</div>
			<div class="col-lg-6 col-md-8 col-sm-6">
				<ul class="breadcrumb">
					<li><a href="{{url('home')}}">Accueil</a></li>
					<li><i class="fa fa-chevron-left"></i></li>
					<li><a href="{{url('courses')}}"></a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<!--Breadcrumb end-->
<!-- Section eleven start -->
@if(isset($statu))
<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-lg-offset-3 col-md-offset-3">
				<div class="ed_teacher_div">
					<div class="ed_heading_top">
						<h3>Résultat de Votre Requête</h3>
                        
                        <div class="alert alert-danger" role="alert">
                          <strong>{{$statu}}</strong>
                        </div>
                         
					</div>
					
					
				</div>
			</div>
		</div>
	</div>


@else
<div class="ed_courses ed_toppadder80 ed_bottompadder80">
	<div class="container">
		<div class="row">
		<div class="col-lg-9 col-md-9 col-sm-12">
			<div class="row">
                @foreach($Courses as $course)
                
                <?php 
                
                $id=$course->id;
                
                $students_number=DB::table('enrolement')->where('course_id',$id)->count();
                
                $instructors=DB::table('users')->join('instructors','instructors.user_id','=','users.id')->join('courses',function($join) use($id){
                    
                    $join->on('courses.prof_id','=','instructors.id')->where('courses.id',$id);
                })->select('instructors.*','users.name','users.image')->get();
                
                ?>
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
					<div class="ed_mostrecomeded_course">
						<div class="ed_item_img">
							<img src="{{asset('images/'.$course->course_image)}}" alt="item1" class="img-responsive">
						</div>
						<div class="ed_item_description ed_most_recomended_data">
							<h4><a href="{{url('course_single/'.$course->id)}}">{{$course->course_title}} </a><span>£{{$course->price}}</span></h4>
							<div class="row">
								<div class="ed_rating">
									<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
										<div class="row">
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
												<div class="ed_stardiv">
													<div class="star-rating"><span style="width:80%;"></span></div>
												</div>
											</div>
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
												<div class="row">
													<p>(5 review)</p>
												</div>
											</div>
										</div>
									</div>
									<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
										<div class="ed_views">
										<i class="fa fa-users"></i>
										<span> {{$students_number}}</span>
										</div>
									</div>
								</div>
							</div>
                            @foreach($instructors as $prof)
							<div class="course_detail">
								<div class="course_faculty">
									<img src="{{asset('images/'.$prof->image)}}" alt=""> <a href="{{url('instructor_dashboard')}}">{{$prof->name}}</a>
								</div>
							</div>
                            @endforeach
							<p>{{$course->description}}</p>
							<a href="{{url('course_single/'.$course->id)}}" class="ed_getinvolved">get involved <i class="fa fa-long-arrow-right"></i></a>
						</div>
					</div>
				</div>
                @endforeach
				
				<div class="col-lg-12">
					<div class="ed_blog_bottom_pagination">
						<nav>
							{{$links}}
						</nav>
					</div>
				</div>
			</div>
		</div>
            @endif
	<!--Sidebar Start-->
		<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
			<div class="sidebar_wrapper_upper">
				<div class="sidebar_wrapper">
					<aside class="widget widget_search">
						<div class="input-group">
							<input type="text" class="form-control" placeholder="Search...">
							<span class="input-group-btn">
								<button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
							</span>
						</div>
					</aside>
					<aside class="widget widget_categories">
						<h4 class="widget-title"> Categories des Cours</h4>
						<ul>
                            
                            <?php   
                            $cats=DB::table('courses_cat')->select('courses_cat.*')->get();
                            
                            ?>
                            @foreach($cats as $cat)
							<li><a href="{{url('course_sidebar/'.$cat->title)}}"><i class="fa fa-chevron-right"></i> {{$cat->title}}</a></li>
                            @endforeach
						</ul>
					</aside>
					<aside class="widget widget_categories">
						<h4 class="widget-title">course type</h4>
						<ul>
							<li><a href="#"><i class="fa fa-chevron-right"></i> all</a></li>
							<li><a href="#"><i class="fa fa-chevron-right"></i> paid</a></li>
							<li><a href="#"><i class="fa fa-chevron-right"></i> free</a></li>
						</ul>
					</aside>
					<aside class="widget widget_categories">
						<h4 class="widget-title">course certification</h4>
						<ul>
							<li><a href="#"><i class="fa fa-chevron-right"></i> diploma</a></li>
							<li><a href="#"><i class="fa fa-chevron-right"></i> graduation</a></li>
							<li><a href="#"><i class="fa fa-chevron-right"></i> post graduation</a></li>
						</ul>
					</aside>
					<aside class="widget widget_tag_cloud">
						<h4 class="widget-title">Search by Tags</h4>
							<a href="#" class="ed_btn ed_orange">university</a>
							<a href="#" class="ed_btn ed_orange">skill</a>
							<a href="#" class="ed_btn ed_orange">tests</a>
							<a href="#" class="ed_btn ed_orange">exams</a>
							<a href="#" class="ed_btn ed_orange">elementary school</a>
							<a href="#" class="ed_btn ed_orange">college</a>
							<a href="#" class="ed_btn ed_orange">edution</a>
					</aside>
				</div>
			</div>
		</div>
<!--Sidebar End-->
		</div>
    </div><!-- /.container -->
</div>
<!-- Section eleven end -->
@endsection