<?php
return ['path'=>'images'];

?>