@extends('events-template')
 <!--header end -->
<!--Breadcrumb start-->
@section('index_body')
<div class="ed_pagetitle">
<div class="ed_img_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-4 col-sm-6">
				<div class="page_title">
					<h2>Cart</h2>
				</div>
			</div>
			<div class="col-lg-6 col-md-8 col-sm-6">
				<ul class="breadcrumb">
					<li><a href="{{url('index2')}}">home</a></li>
					<li><i class="fa fa-chevron-left"></i></li>
					<li><a href="{{url('cart')}}">Cart</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<!--Breadcrumb end-->
<!--Cart page start-->
<div class="ed_graysection ed_toppadder80 ed_bottompadder80">
  <div class="container">
    <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="woo-cart-table">
			<div class="table-responsive">          
			  <table class="table table-bordered">
				<thead>
				  <tr>
					<th>S.No.</th>
					<th>courses image</th>
					<th>courses</th>
					<th>quantity</th>
					<th>total</th>
					<th>remove</th>
				  </tr>
				</thead>
				<tbody>
				  <tr>
					<td>1</td>
					<td><img src="http://placehold.it/100X50" alt="event image" /></td>
					<td>Project Learning</td>
					<td>1</td>
					<td><span>£25</span></td>
					<td><a href="#" data-toggle="tooltip" data-placement="bottom" title="Remove Item">x</a></td>
				  </tr>
				   <tr>
					<td>2</td>
					<td><img src="http://placehold.it/100X50" alt="event image" /></td>
					<td>user experience jam</td>
					<td>1</td>
					<td><span>£38</span></td>
					<td><a href="#" data-toggle="tooltip" data-placement="bottom" title="Remove Item">x</a></td>
				  </tr>
				   <tr>
					<td colspan="3">
						<div class="woo_coupon_code">
							<form class="form-inline">
								<div class="form-group">
									<input type="text" name="coupon_code" class="form-control" value="" placeholder="Coupon code">
								</div>
								<div class="form-group">
									<input type="submit" class="btn ed_btn ed_green" name="apply_coupon" value="Apply Coupon">
								</div>
							</form>
						</div>
					</td>
					<td colspan="3">
						<div class="ed_update_btn">
							<input type="submit" class="btn ed_btn ed_green" name="update_cart" value="Update Cart">
						</div>
					</td>
				  </tr>
				</tbody>
			  </table>
			  </div>
		</div>
		</div>

	<div class="ed_cart_collaterals">
	<div class="cart_totals">	
		<h2>Cart Totals</h2>
		<table class="table table-bordered">
			<tbody>
				<tr class="cart-subtotal">
					<th>Subtotal</th>
					<td><span class="amount">£63.00</span></td>
				</tr>
				<tr class="order-total">
					<th>Total</th>
					<td><span class="amount">£63.00</span> </td>
				</tr>
			</tbody>
		</table>	
		<div class="wc-proceed-to-checkout">
			<a href="{{url('checkout')}}" class="btn ed_btn ed_green">Proceed to Checkout</a>
		</div>
	</div>
	</div>
		
	</div>
  </div>  
</div>
<!--cart page end-->
@endsection