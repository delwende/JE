@extends('layouts.pass-template')

@section('index_body')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Changer de Mot de Passe</div>
                <div class="panel-body">
                
                    {!!Form:: open(['route'=>'password.email','class'=>'ed_contact_form ed_toppadder40'])!!}
                    
                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            {!!Form::email('email',old('email'), ['class'=>'form-control','placeholder'=>'Email'])!!}
                            {!!$errors->first('email','<small class="help-block">:message</small>')!!}
                                
                        
                        </div>

                        <div class="form-group">
                            
                             {!!Form::submit('Envoyer', ['class'=>'btn btn-primary'])!!}
                                
                        </div>
                    {!!Form::close()!!}
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
