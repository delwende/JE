@extends('layouts.pass-template')

@section('body_index')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Changer de Mot de Passe</div>

                
                    
                    {!!Form:: open(['route'=>'password.request','class'=>'ed_contact_form ed_toppadder40'])!!}
                    {!!Form::hidden('token',['token'=>$token])!!}
                    
                        

                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            
                              {!!Form::label('emaillabel','Email',['class'=>'col-md-4 control-label'])!!}
                            <div class="col-md-6">
                                {!!Form::email('email', old('email')?$email:'', ['class'=>'form-control','placeholder'=>'Email'])!!}
                                {!!$errors->first('email','<small class="help-block">:message</small>')!!}
                                
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            {!!Form::label('passlabel','Mot de Passe',['class'=>'col-md-4 control-label'])!!}
                            

                            <div class="col-md-6">
                                {!!Form::password('password',['class'=>'form-control','placeholder'=>'Mot de passe'])!!}
                                {!!$errors->first('password','<small class="help-block">:message</small>')!!}

                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('password_confirmation') ? ' has-error' : '' }}">
                            {!!Form::label('confirm_pass','Confirmer Mot de Passe', ['class'=>'col-md-4 control-label'])!!}
                            <div class="col-md-6">
                                {!!Form::password('password_confirmation',['class'=>'form-control','placeholder'=>'Confirmer le mot de passe'])!!}
                                {!!$errors->first('password_confirmation', '<small class="help-block">:message</small>')!!}
                                
                            </div>
                        </div>

                        <div class="form-group">
                            
                                {!!Form::submit('Envoyer', ['class'=>'btn btn-primary'])!!}
                                
                        
                        </div>
                    {!!Form::close()!!}
                    
                </div>
            </div>
        </div>
    </div>

@endsection
