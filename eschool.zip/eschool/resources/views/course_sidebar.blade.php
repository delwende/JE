@extends('checkout-template')
<!--header end -->
<!--Breadcrumb start-->
@section('index_body')
<div class="ed_pagetitle">
<div class="ed_img_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-4 col-sm-6">
				<div class="page_title">
					<h2>Cours</h2>
				</div>
			</div>
			<div class="col-lg-6 col-md-8 col-sm-6">
				<ul class="breadcrumb">
					<li><a href="{{url('home')}}">Accueil</a></li>
					<li><i class="fa fa-chevron-left"></i></li>
					<li><a href="{{url('courses')}}">Cours</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<!--Breadcrumb end-->
<!-- Section eleven start -->
<div class="ed_courses ed_toppadder80 ed_bottompadder80">
	<div class="container">
		<div class="row">
		  @foreach($courses as $course)
			<?php
			$students_number=DB::table('enrolement')->where('course_id','=',$course->id)->count();
			$auter=DB::table('users')->where('id','=',$course->prof_id)->first();

			?>
		<div class="col-lg-9 col-md-9 col-sm-12">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
					<div class="ed_mostrecomeded_course">
						<div class="ed_item_img">
							<img src="{{asset('images/'.$course->course_image)}}" alt="item1" class="img-responsive">
						</div>
						<div class="ed_item_description ed_most_recomended_data">
							<h4><a href="{{url('course_single')}}">{{$course->course_title}}  </a><span>£{{$course->price}}</span></h4>
							<div class="row">
								<div class="ed_rating">
									<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
										<div class="row">
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
												<div class="ed_stardiv">
													<div class="star-rating"><span style="width:80%;"></span></div>
												</div>
											</div>
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
												<div class="row">
													<p>(5 review)</p>
												</div>
											</div>
										</div>
									</div>
									<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
										<div class="ed_views">
										<i class="fa fa-users"></i>
										<span>{!!$students_number!!} etudiants</span>
										</div>
									</div>
								</div>
							</div>
							<div class="course_detail">
								<div class="course_faculty">
									<img src="{{asset('images/'.$auter->image)}}" alt=""> <a href="{{url('instructor_dashboard')}}">{{$auter->name}}</a>
								</div>
							</div>
							<p>{{$course->description}}</p>
							<a href="{{url('course_single')}}" class="ed_getinvolved">participer<i class="fa fa-long-arrow-right"></i></a>
						</div>
					</div>
				</div>
				
				
				<div class="col-lg-12">
					<div class="ed_blog_bottom_pagination">
						<nav>
							<ul class="pagination">
								{!! $courses->render() !!}
								
							</ul>
						</nav>
					</div>
				</div>
			</div>
		</div>
		@endforeach
	<!--Sidebar Start-->
		<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
			<div class="sidebar_wrapper_upper">
				<div class="sidebar_wrapper">
					<aside class="widget widget_search">
						<div class="input-group">
							<input type="text" class="form-control" placeholder="Search...">
							<span class="input-group-btn">
								<button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
							</span>
						</div>
					</aside>
					<aside class="widget widget_categories">
						<h4 class="widget-title">Catégorie de cours</h4>
						<ul>
						<?php
						$categories=DB::table('courses_cat')->get();?>

						@foreach($categories as $category)
							<li><a href="{{url($category->title)}}">
								<i class="fa fa-chevron-right"></i>
									{!!$category->title!!} 
								</a>
							</li>
						@endforeach
							
							
						</ul>
					</aside>
					<aside class="widget widget_categories">
						<h4 class="widget-title">Type de cours</h4>
						<ul>
							<li><a href="#"><i class="fa fa-chevron-right"></i> Tout</a></li>
							<li><a href="#"><i class="fa fa-chevron-right"></i> payant</a></li>
							<li><a href="#"><i class="fa fa-chevron-right"></i> gratuit</a></li>
						</ul>
					</aside>
					<aside class="widget widget_categories">
						<h4 class="widget-title">course certification</h4>
						<ul>
							<li><a href="#"><i class="fa fa-chevron-right"></i> Licence</a></li>
							<li><a href="#"><i class="fa fa-chevron-right"></i> Master</a></li>
							<li><a href="#"><i class="fa fa-chevron-right"></i> Doctorat </a></li>
						</ul>
					</aside>
					<aside class="widget widget_tag_cloud">
						<h4 class="widget-title">Search by Tags</h4>
							<a href="#" class="ed_btn ed_orange">university</a>
							<a href="#" class="ed_btn ed_orange">skill</a>
							<a href="#" class="ed_btn ed_orange">tests</a>
							<a href="#" class="ed_btn ed_orange">exams</a>
							<a href="#" class="ed_btn ed_orange">elementary school</a>
							<a href="#" class="ed_btn ed_orange">college</a>
							<a href="#" class="ed_btn ed_orange">edution</a>
					</aside>
				</div>
			</div>
		</div>
<!--Sidebar End-->
		</div>
    </div><!-- /.container -->
</div>
<!-- Section eleven end -->
@endsection