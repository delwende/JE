@extends('template')
<!--header end -->
<!--Error Page Section start-->
@section('index_body')
<div class="ed_error_wrapper">
<div class="ed_img_overlay"></div>
	<div class="container">
		<div class="ed_error_content ed_toppadder100 ed_bottompadder100">
			<h1 class="ed_bottompadder40">404</h1>
			<h3 class="ed_bottompadder40">You found yourself on the lonely place. Return back to the home page</h3>
			<span><a href="#" class="btn ed_btn ed_orange pull-left">Return Back</a></span>
		</div>
	</div>
</div>
<!--Error Page Section end-->
@endsection