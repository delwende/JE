@extends('events-template')
 <!--header end -->
<!--Breadcrumb start-->
@section('index_body')
<div class="ed_pagetitle">
<div class="ed_img_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-4 col-sm-6">
				<div class="page_title">
					<h2>Educo Teacher</h2>
				</div>
			</div>
			<div class="col-lg-6 col-md-8 col-sm-6">
				<ul class="breadcrumb">
					<li><a href="index.html">home</a></li>
					<li><i class="fa fa-chevron-left"></i></li>
					<li><a href="become_teacher.html">Educo Teacher</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<!--Breadcrumb end-->
<!--teacher_form_wrapper start-->
<div class="ed_graysection ed_toppadder80 ed_bottompadder80">
  <div class="container">
    <div class="row">
			<div class="col-lg-6 col-md-6 col-sm-12 col-lg-offset-3 col-md-offset-3">
				<div class="ed_teacher_div">
					<h3>Fill this form and become a <span>Teacher <i class="fa fa-hand-o-down"></i></span></h3>
					<form class="ed_teacher_form">
						<div class="form-group">
							<label class="control-label">First Name:</label>
							<input type="text" class="form-control" >
						</div>
						<div class="form-group">
							<label class="control-label">Last Name:</label>
							<input type="text" class="form-control" >
						</div>
						<div class="form-group">
							<label class="control-label">Email:</label>
							<input type="text" class="form-control" >
						</div>
						<div class="form-group">
							<label  class="control-label">Password:</label>
							<input type="password" class="form-control">
						</div>
						<div class="form-group">
							<label  class="control-label">Password Confirm:</label>
							<input type="password" class="form-control">
						</div>
						
						<button type="Submit" class="btn ed_btn ed_green">Join</button>
						
					</form>
				</div>
			</div>
	</div>
  </div>  
</div>
@endsection
