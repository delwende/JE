@extends('checkout-template')

@section('index_body')
<div class="ed_pagetitle">
<div class="ed_img_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-4 col-sm-6">
				<div class="page_title">
					<h2>S'inscrire</h2>
				</div>
			</div>
			<div class="col-lg-6 col-md-8 col-sm-6">
				<ul class="breadcrumb">
					<li><a href="{{url('index2')}}">Accueil</a></li>
					<li><i class="fa fa-chevron-left"></i></li>
					<li><a href="#">S'inscrire</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<!--Breadcrumb end-->
<div class="ed_transprentbg ed_toppadder80 ed_bottompadder80">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-lg-offset-3 col-md-offset-3">
				<div class="ed_teacher_div">
					<div class="ed_heading_top">
						<h3>S'inscrire</h3>
					</div>
					{!!Form::open(['route'=>'create_course.store','class'=>'ed_contact_form ed_toppadder40', 'files'=>'true'])!!} 
						<div class="form-group {!!$errors->has('name')?'has-error':''!!}">
							{!!Form::text('name',null,['class'=>'form-control', 'placeholder'=>'Titre du cours'])!!} {!!$errors->first('name', '<small class="help-block">:message</small>')!!}
						</div>
						<div class="form-group {!! $errors->has('description')?'has-error':''!!}">
							{!!Form::textarea('description', null,['class'=>'form-control','placeholder'=>'Description du Cours'])!!}
                            {!!$errors->first('description','<small class="help-block">:message</small>')!!}
						</div>
							<div class="form-group {!!$errors->has('category')?'has-error':''!!}">
							{!!Form::select('category' ,array(
                            'Choisir la Catégorie du cours',
                            '1'=>'Développement Web',
                            '2'=>'Développement mobile',
                            '3'=>'Business management',
                            '4'=>'Langues',
                            '5'=>'Motivation'
                            
                            ),['class'=>'form-control','id'=>'selectCat'])!!}
                            {!!$errors->first('category','<small class="help-block">:message</small>')!!}
						</div>
                    <div class="form-group {!!$errors->has('price')?'has-error':''!!}">
							{!!Form::text('price','Gratuit',['class'=>'form-control','placeholder'=>'price'])!!}
                            {!!$errors->first('price','<small class="help-block">:message</small>')!!}
						</div>
                    <div class="form-group {!!$errors->has('sale')?'has-error':''!!}">
							{!!Form::number('sale',null,['class'=>'form-control','placeholder'=>'Prix Promo'])!!}
                            {!!$errors->first('sale','<small class="help-block">:message</small>')!!}
						</div>
                    <div class="form-group {!!$errors->has('langue')?'has-error':''!!}">
                    
							{!!Form::select('langue', array(
                            'Langue du cours',
                            'Moore'=>'Moore',
                            'Dioula'=>'Dioula',
                            'Wolof'=>'Wolof',
                            'Swahili'=>'Swahili',
                            'Fula'=>'Fula',
                            'Yoruba'=>'Yoruba',
                            'Twi'=>'twi'
                            
                            ),['class'=>'form-control','id'=>'selectLangue'])!!}
                            {!!$errors->first('langue','<small class="help-block">:message</small>')!!}
						</div>
                    <div class="form-group {!!$errors->has('duration')?'has-error':''!!}">
							{!!Form::number('duration','Gratuit',['class'=>'form-control','placeholder'=>'Durée du cours en semaines'])!!}
                            {!!$errors->first('duration','<small class="help-block">:message</small>')!!}
						</div>
                    <div class="form-group {!!$errors->has('image')?'has-error':''!!}">
                        {!!Form::label('imageCourse','Image du Cours')!!}
							{!!Form::file('image',['class'=>'form-control','placeholder'=>'image du cours','id'=>'imageCourse'])!!}
                            {!!$errors->first('image','<small class="help-block">:message</small>')!!}
						</div>
                    <div class="form-group {!! $errors->has('video[]')?'has-error':''!!}">
                        
                        {!!Form::label('CourseVideo', 'Les Vidéos de votre Cours')!!}
                        <div class="lesson_container">
                        <div>
                        {!!Form::text('lesson_title[]',null,['class'=>'form-control','placeholder'=>'Titre de la Lesson'])!!}
                      {!! Form::file('video[]',['class'=>'form-control','id'=>'CourseVideo'])!!}
                      {!!
                       $errors->first('video[]','<small class="help-block">:message</small>')
                      !!}
                            </div>
                        <div class="row"></div>
                            <br>
                        {!!Form::button('Ajouter une lesson &nbsp;<i class="fa fa-plus" aria-hidden="true"></i>
',['class'=>'btn ed_btn ed_orange pull-left','id'=>'add_lesson'])!!}
                            
                            </div>
                        <br>
                            
                   </div>
                    {!!Form::hidden('prof_id',$prof_id)!!}
						{!! Form::submit('Enregistrer',['class'=>'btn ed_btn ed_orange pull-right'])!!}
                    {!!Form::close()!!}
					
					
				</div>
			</div>
		</div>
	</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script>
   $(document).ready(function()
                    {
       var wrapper=$(".lesson_container");
       var add=$("#add_lesson");
       $(add).click(function(e)
                   {
           e.preventDefault();
           $(wrapper).append('<br> <br><br><div><label for="newvideo">Ajouter une Video</label><input type="text" name="lesson_title[]" value="" class="form-control", placeholder="Titre de la lesson"  id="newvideo" required><input type="file" name="video[]" class="form-control" required><div></div><br><button href="#" class="btn-primary" id="delete">Suprimer &nbsp;<i class="fa fa-trash-o" aria-hidden="true"></i></button></div>')
           
       });
       $(wrapper).on("click","#delete", function(e){
         e.preventDefault();
           $(this).parent('div').remove();
       });
       
   });
</script>
@endsection
