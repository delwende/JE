<?php


namespace App\Repositories;

use App\User;
use App\Http\Requests\UsercreateRequest;
class UserRepository{
    
    
    protected $user;
    
    public function __construc(User $user)
    {
       $this ->user=$user;
    }
    private function save (User $user, Array $inputs)
    {
        
        
      $user->name=$inputs['name'];
    $user->email=$inputs['email'];
    $user->image=$inputs['image'];
    
        $user->save();
    }
    public function store(Array $inputs)
    {
       $user= new User();
        
        $user->password=bcrypt($inputs['password']);
        $this->save($user,$inputs);
        return $user;
    }
    public function getByid ($id)
    {
        return $this->user->findOrfail($id);
    }
    public function update($id, Array $inputs)
    {
        $this->save($this->getByid($id),$inputs);
    }
    
    public function destroy ($id)
    {
        $this->getByid($id)->delete();
    }
}

?>