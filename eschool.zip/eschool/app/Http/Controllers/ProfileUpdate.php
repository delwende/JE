<?php

namespace App\Http\Controllers;

use Auth;
use App\instructors;
use DB;
use App\User;
use Illuminate\Http\Request;
use App\Repositories\UserRepository;
use App\Http\Requests\UsercreateRequest;
use App\Http\Requests\UserupdateRequest;
use Illuminate\Support\Facades\Input; 

class ProfileUpdate extends Controller
{
    //
      protected $user;
    
  
       public function index(){
       
       	 $id=Auth::user()->id;
       	 $this->user= new User();
        $user=$this->getByid($id);
        /*var_dump($user);
        echo $user;*/
        return view('home');
       }
    
public function update(Request $request)
    {
      $id=Auth::user()->id;
       	 $this->user= new User();
        $user=$this->getByid($id);
        
      // $data=$request->all();
         $new_image =$request->file('image');
       	//$new_image=$request->input('image');
        $image_name =(!empty($request->hasFile('image')))?$new_image->getClientOriginalName():$user->image;
       // $image_name=$image->getClientOriginalName();
        $name=(!empty($request->input('name')))?$request->input('name'):$user->name;
        $email=(!empty($request->input('email')))?$request->input('email'):$user->email;
        $password=(!empty($request->input('password')))?bcrypt($request->input('password')):$user->password;
        
        if(!empty($new_image)){
        	$way=public_path('images');
        	$new_image->move($way,$image_name);
        }
        

        $user->name=$name;
        $user->email=$email;
        $user->image=$image_name;
        $user->password=$password;


        $user->save();


        // the new user profile
       /* if(!$data['image']->empty()){
           $image =$request->file('image');
       /* if($request->hasFile('image'))
        {
            if($image->isValid())
            {
                
                $way=public_path('images');
                
                $extension=$image->getClientOriginalExtension();
                
                
                
                    $name=$image->getClientOriginalName();
                    //echo $name;
                
                if(file_exists($way.'/'.$name))
                {
                   
                    if($image->move($way,$name))
                {
                    
                    //echo'ok '; //75485205
                    //echo $name;
                        $data= array_merge($request->all(),['image'=>$name]);
                   
                 }
                    
                }
                
                
                
            }
            
        }
        }
        if($data['image']->empty()){ //if user does not change the profile image
          $data['image']=Auth::user()->image;
        }
        if($data['email']->empty()){ //when the email field is empty keep the same email
          $data['email']=Auth::user()->email;
            
        }
         if($data['name']->empty()){ //when the email field is empty keep the same email
          $data['name']=Auth::user()->name;
            
        }
        
        if(!$data['password']->empty()){ // if the password has changed
          $data['password']=bcrypt($data['password']);
        }
         if($data['password']->empty()){
          $data['password']=Auth::user()->password;
        }*/

 //$this->save($this->getByid($id),$data);
       /* else{
          
           $this->save($this->getByid($id),$data);
          //return route('password.request');
      //  $this->userRepository->update($id, $request->all());
        
        
        }*/
       return  redirect('dashboard');
    }

public function getByid ($id)
    {
        return $this->user->findOrfail($id);
    }
     private function save (User $user, Array $inputs)
    {
        
        
      $user->name=$inputs['name'];
    $user->email=$inputs['email'];
    $user->image=$inputs['image'];
     $user->image=$inputs['password'];
        $user->save();
    }
}
