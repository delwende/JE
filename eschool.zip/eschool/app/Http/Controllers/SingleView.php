<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class SingleView extends Controller
{
    
    public function show($id)
        
    {
        $course=DB::table('courses')->join('course_videos','course_videos.course_id','=',$id)->select('courses.*','course_videos.*');
        
        return redirect('course_single')->with(compact('course'));
        
    }
    //
}
