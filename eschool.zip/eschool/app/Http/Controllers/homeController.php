<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\View;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    /*public function __construct()
    {
        $this->middleware('');
    }*/

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $courses=DB::table('courses')->join('instructors','courses.prof_id','=','instructors.id')->join('users','instructors.user_id','=','users.id')->select('courses.*','users.*')->get();                         
         
        $i=0;
        return View::make('home')->with(compact('courses','i'));
    }
}
