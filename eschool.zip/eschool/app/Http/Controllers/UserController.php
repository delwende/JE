<?php

namespace App\Http\Controllers;

use App\Http\Requests\UsercreateRequest;
use App\Http\Requests\UserupdateRequest;
use App\Repositories\UserRepository;
use Illuminate\Http\Request;
class UserController extends Controller
{
    
    protected $userRepository;
    protected $nbrPerPage=4;
    
    
    public function __construct(UserRepository $UserRepository)
    {
        $this->userRepository=$UserRepository;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       return view('signup');
        //
    }
    

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('signup');
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(UsercreateRequest $request)
    {
        
         $image =$request->file('image');
        if($request->hasFile('image'))
        {
            if($image->isValid())
            {
                
                $way=public_path('images');
                
                $extension=$image->getClientOriginalExtension();
                
                
                
                    $name=$image->getClientOriginalName();
                    //echo $name;
                
                if(file_exists($way.'/'.$name))
                {
                   
                    if($image->move($way,$name))
                {
                    
                    //echo'ok '; //75485205
                    //echo $name;
                        $data= array_merge($request->all(),['image'=>$name]);
                    $user=$this->userRepository->store($data);
                    return redirect('home')->with(['user'=>$user,'statu'=>'Votre souscription a réussi !connectez vous']);
                 }
                    
                }
                
                
                
            }
            
        }
        return redirect('signup')->withErrors(" L'enrisgrement n'a pas abouti !");
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user=$this->userRepository->getByid($id);
        
        return view('dashboard', compact('user'));
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user=$this->userRepository->getByid($id);
        
        return view('dashboard', compact('user'));
            //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UserupdateRequest $request, $id)
    {
        $this->userRepository->update($id, $request->all());
        
        return view('dashboard');
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $this->userRepository->destroy($id);
        return back();
        //
    }
}
