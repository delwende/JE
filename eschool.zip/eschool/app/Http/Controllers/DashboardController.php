<?php
namespace App\Http\Controllers;
use Auth;
use App\instructors;
use DB;
use Illuminate\Http\Request;
use App\Repositories\UserRepository;
use App\Http\Requests\UsercreateRequest;
use Illuminate\Support\Facades\Input; 
class DashboardController extends Controller
{
    
     protected $content;
      public function index()
    {
    	$is_instructor=0;
$courses="";
    	$user_id=Auth::user()->id;
    	$check_if_instructor = DB::table('instructors')->where('user_id', '=', $user_id)->first();
    	if($check_if_instructor){
    		$is_instructor=1;
    	}

$courses=$this->getcourses($user_id);
$mesNombredeCours=$this->MesNombredeCours($user_id);
$mescourses=$this->createdCourse($user_id);
$Numberofcreatedcourse=$this->NumberofCreatedCourse($user_id);
        return view('dashboard',['is_instructor' => $is_instructor,'courses'=>$courses,'mesNombredeCours'=>$mesNombredeCours,'mescourses'=>$mescourses,'Numberofcreatedcourse'=>$Numberofcreatedcourse]);
    }
//lES COURS AUQUEL L UTILISATEUR PARTICIPE
    public function getcourses($user_id){
$courses = DB::table('courses')
            ->join('enrolement', 'enrolement.course_id', '=', 'courses.id')->where('enrolement.student_id', '=', $user_id)
            ->select('courses.*', 'enrolement.*')
            ->get();
            return $courses;

    }
public function MesNombredeCours($user_id) { 
$mesNbrdeCours=DB::table('enrolement')->where('student_id','=',$user_id)->count();
return $mesNbrdeCours;
	}

	public function createdCourse($user_id){
$mescours=DB::table('courses')->where('prof_id','=',$user_id)->get();
return $mescours;
	}
	public function NumberofCreatedCourse($user_id){
		$Numofmescours=DB::table('courses')->where('prof_id','=',$user_id)->count();
return $Numofmescours;
	}
    public function becomeProf(Request $request){

/*$this->validate($request, [
			'name'=> 'required',
			'family_name'=> 'required',
			'email'=>'required|email|max:255|unique:instructors',
          'title' => 'required',
          'intro'=> 'required', 
          'location'=> 'required'
          ]);
*/
          $input = $request->all();

          $input['user_id'] = Auth::user()->id;

          instructors::create($input);

          return view('dashboard');
    	
    }
    
}
