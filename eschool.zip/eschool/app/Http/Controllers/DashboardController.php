<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Repositories\UserRepository;
use App\Http\Requests\UsercreateRequest;
class DashboardController extends Controller
{
    
    
    
}
