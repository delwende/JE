<?php
namespace App\Http\Controllers;
use Auth;
use App\instructors;
use DB;
use Illuminate\Http\Request;
use App\Repositories\UserRepository;
use App\Http\Requests\UsercreateRequest;
use App\Http\Requests\UserupdateRequest;
use Illuminate\Support\Facades\Input; 
use Illuminate\Support\Facades\View;
class Course_sidebar extends Controller
{
    //

    public function index(){

return view('course_sidebar');
    	
    }

   

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
public function display($cat_title){
$courses = DB::table('courses')
            ->join('courses_cat', 'courses_cat.id', '=', 'courses.cat_id')->where('courses_cat.title', '=', $cat_title)
            ->select('courses.*')
            ->paginate(1);
       return view('course_sidebar')->with('courses',$courses);
}
    
    public function show($cat_title)
    {
        //
//echo $title;

$courses = DB::table('courses')
            ->join('courses_cat', 'courses_cat.id', '=', 'courses.cat_id')->where('courses_cat.title', '=', $cat_title)
            ->select('courses.*')
            ->get();
       return view('course_sidebar',['courses'=>$courses]);
    	
    }



    
}
