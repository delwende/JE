<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\CreateCourseRequest;
use Illuminate\Support\Collection;
use App\Course;
use App\lessons;
use Illuminate\Support\Facades\Auth;
use Validator;
class CreateCourse extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
     
    public function index()
    {
        if(Auth::guest())
        {
            return redirect('login');
            
        }
        $prof_id=Auth::id();
        
        return view('create_course', compact('prof_id'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        
       return view('create_course');
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {/******************************
        *                             *
        *          Validation         *
        *******************************/
        $validator=Validator::make($request->all(),
                       [
                           
            'name'=>'required|string|max:255',
            'description'=>'required|string',
            'category'=>'required|string',
            'price'=>'required|string',
            'sale'=>'string',
            'langue'=>'required|string',
            'duration'=>'required|integer',
             'image'=>'required|image',
            'prof_id'=>'required|integer',
            'video'=>'required|array',
            'video.*'=>'file|mimes:mp4,mov,wmv',
            'lesson_title'=>'required|array',
              'lesson_title.*'=>'string|max:255'
                       ]
                       );
        
        if($validator->fails())
        {
            return redirect('create_course');
        }
        
        /******************************
        *                             *
        *          Declaration        *
        *******************************/
       // dd($request->all());
        $videos =$request->file('video');
        $lesson_titles=$request->input('lesson_title');
         
        $Course=new Course();
        $file_cout=count($videos);
        $upload_count=0;
        
         $image =$request->file('image');
        
        $imgName=$image->getClientOriginalName();
        $imageWay=public_path('images');
       
        $image->move($imageWay,$imgName);
        
        
        
        
        
        /******************************
        *                             *
        *  store videos files name    *
        *  in lessons table           *
        *******************************/
        
        
        
        
        
        /******************************
        *                             *
        * save course in Courses table*
        *******************************/
        
        $Course->course_title=$request->input('name');
        $Course->prof_id=$request->input('prof_id');
        $Course->description=$request->input('description');
        $Course->price=$request->input('price');
        $Course->sale=$request->input('sale');
        $Course->duration=$request->input('duration');
        $Course->course_image=$imgName;
        $Course->cat_id=$request->input('category');
        $Course->langue=$request->input('langue');
        $Course->save();
        
        /******************************
        *                             *
        *  store lessons title and    *
        * course_id in lessons table   *
        *******************************/
       
        foreach($videos as $video)
        {
            $lessons=new lessons();
           $filename=$video->getClientOriginalName();
            $vidWay=public_path('videos');
            $lessons->video=$filename;
           // echo $filename;
            $video->move($vidWay,$filename);
            $lessons->title=$lesson_titles[$upload_count];
            $lessons->course_id=$Course->id;
            $lessons->save();
            $upload_count++;
                // echo $filename;
        }
        
        $id=$Course->id;
        
        return redirect()->route('course_single',[$id]);
        
        
        
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
