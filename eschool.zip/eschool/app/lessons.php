<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class lessons extends Model
{
    protected $table='course_videos';
    public $timestamps=false;
    //
}
