<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home');
});

Route::get('/home' ,function ()
           {
               return view('home');
           });
Route::get('/about',function()
           {
               return view('about');
           });

Route::get('courses', function()
           {
               return view('courses');
           });
Route:: get('/become_teacher', function()
            {
                return view('become_teacher');
            });
Route::get('/cart',function()
           {
               return view('cart');
           });
Route::get('/instructor', function()
           {
               return view('instructor');
           });
Route::get('events', function(){
    
    return view('events');
});
Route::get('/checkout', function()
           {
               return view('checkout');
           });
Route::get('/contact',function()
           {
               return view('contact');
           });
Route:: get('/signup',function()
            {
                return view('signup');
            });
Route::get('/course_sidebar', function()
           {
               return view('course_sidebar');
               
           });
Route::get('/event_single', function(){
    
    return view('event_single');
});
Route::get('/instructor_dashboard', function()
           {
               return view('instructor_dashboard');
           });
Route::get('/course_single', function()
           {
               return view('course_single');
           });
Route::get('/private_policy',function (){
    
    return view ('private_policy');
});
Route::get('/dashboard',function()
           {
               return view('dashboard');
           });