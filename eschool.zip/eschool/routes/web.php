<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home');
});


Route::get('/about',function()
           {
               return view('about');
           });

Route::get('courses', function()
           {
               return view('courses');
           });
Route:: resource('/become_teacher','InstructorController' );
Route::get('/cart',function()
           {
               return view('cart');
           });
Route::get('/instructor', function()
           {
               return view('instructor');
           });
Route::get('events', function(){
    
    return view('events');
});
Route::get('/checkout', function()
           {
               return view('checkout');
           });
Route::get('/contact',function()
           {
               return view('contact');
           });

Route::get('/course_sidebar', function()
           {
               return view('course_sidebar');
               
           });
Route::get('/event_single', function(){
    
    return view('event_single');
});
Route::get('/instructor_dashboard', function()
           {
               return view('instructor_dashboard');
           });
Route::resource('/course_single','Course_view');
Route::get('/private_policy',function (){
    
    return view ('private_policy');
});
Route::get('/dashboard',function()
           {
               return view('dashboard');
           });
Route::resource('/signup','UserController');
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::resource('/create_course','CreateCourse');
