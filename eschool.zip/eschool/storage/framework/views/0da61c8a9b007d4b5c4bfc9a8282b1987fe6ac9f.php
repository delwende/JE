<!DOCTYPE html>
<!-- 
Template Name: Educo
Version: 3.0.0
Author: Kamleshyadav
Website: http://himanshusofttech.com/
Purchase: http://themeforest.net/user/kamleshyadav
-->
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<!--<![endif]-->

<!-- Begin Head -->
<head>
<meta charset="utf-8" />
<title>Educo Multipurpose Responsive HTML Template</title>
<meta content="width=device-width, initial-scale=1.0" name="viewport" />
<meta name="description"  content="Educo"/>
<meta name="keywords" content="Educo, html template, Education template" />
<meta name="author"  content="Kamleshyadav"/>
<meta name="MobileOptimized" content="320" />

<!--srart theme style -->
<link href="css/main.css" rel="stylesheet" type="text/css"/>
<!-- end theme style -->
<!-- favicon links -->
<link rel="shortcut icon" type="image/png" href="images/header/favicon.png" />
</head>
<body>
<!--Page main section start-->
<div id="educo_wrapper">
<!--Header start-->
<header id="ed_header_wrapper">
	<div class="ed_header_top">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12">
					<p>welcome to our new session of education</p>
					<div class="ed_info_wrapper">
						<a href="#" id="login_button">Login</a>
							<div id="login_one" class="ed_login_form">
								<h3>log in</h3>
								<form class="form">
									<div class="form-group">
										<label class="control-label">Email :</label>
										<input type="text" class="form-control" >
									</div>
									<div class="form-group">
										<label  class="control-label">Password :</label>
										<input type="password" class="form-control">
									</div>
									<div class="form-group">
										<button type="submit">login</button>
										<a href="signup.html">registration</a>	
									</div>
								</form>
							</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="ed_header_bottom">
		<div class="container">
			<div class="row">
				<div class="col-lg-2 col-md-2 col-sm-2">
					<div class="educo_logo"> <a href="index.html"><img src="images/header/Logo.png" alt="logo" /></a> </div>
				</div>
				<div class="col-lg-8 col-md-8 col-sm-8">
					<div class="edoco_menu_toggle navbar-toggle" data-toggle="collapse" data-target="#ed_menu">Menu <i class="fa fa-bars"></i>
					</div>
					<div class="edoco_menu">
						<ul class="collapse navbar-collapse" id="ed_menu">
							<li><a href="#">Home</a>
								<ul class="sub-menu">
									<li><a href="index.html">Home</a></li>
									<li><a href="index2.html">home-2</a></li>
								</ul>
							</li>
							<li><a href="about.html">about us</a></li>
							<li><a href="#">blog</a>
								<ul class="sub-menu">
									<li><a href="blog.html">blog-large</a></li>
									<li><a href="blog_med.html">blog-medium</a></li>
									<li><a href="blog_single.html">blog-single</a></li>
								</ul>
							</li>
							<li><a href="#">events</a>
								<ul class="sub-menu">
									<li><a href="events.html">all events</a></li>
									<li><a href="event_single.html">events-single</a></li>
								</ul>
							</li>
							<li><a href="#">courses</a>
								<ul class="sub-menu">
									<li><a href="courses.html">all courses</a></li>
									<li><a href="course_sidebar.html">course-sidebar</a></li>
									<li><a href="course_single.html">course-single</a></li>
									<li><a href="course_lesson.html">course-lesson</a></li>
								</ul>
							</li>
							<li><a href="#">Pages</a>
								<ul class="sub-menu">
									<li><a href="instructor.html">all instructor</a></li>
									<li><a href="instructor_dashboard.html">instructor dashboard</a></li>
									<li><a href="dashboard.html">student dashboard</a></li>
									<li><a href="become_teacher.html">Become teacher</a></li>
									<li><a href="pricing_table.html">pricing table</a></li>
									<li><a href="cart.html">cart</a></li>
									<li><a href="checkout.html">checkout</a></li>
									<li><a href="purchase_course.html">purchase course</a></li>
									<li><a href="not_found.html">404 error</a></li>
								</ul>
							</li>
							<li><a href="contact.html">Contact</a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2">
					<div class="educo_call"><i class="fa fa-phone"></i><a href="#">1-220-090</a></div>
				</div>
			</div>
		</div>
    </div>
</header>
<!--header end -->
<div class="ed_slider_form_section">
<!--Slider start-->
	<section class="ed_mainslider">
		<article class="content">
			<div class="rev_slider_wrapper">			
				<!-- START REVOLUTION SLIDER 5.0 auto mode -->
				<div id="rev_slider_4_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" data-alias="classicslider1" style="margin:0px auto;background-color:transparent;padding:0px;margin-top:0px;margin-bottom:0px;">
				<div id="rev_slider" class="rev_slider "  data-version="5.0">
					<ul>	
						<!-- SLIDE  -->
						<li data-transition="slotslide-horizontal">
							
							<!-- MAIN IMAGE -->
							<img src="http://placehold.it/1920X1080"  alt="">
							<div class="ed_course_single_image_overlay"></div>

							<!-- LAYER NR. 1 -->
								<div class="tp-caption NotGeneric-Title   tp-resizeme rs-parallaxlevel-0" 

									 data-x="['left','left','left','left']" data-hoffset="['45','60','60','40']" 
									data-y="['top','top','top','top']" data-voffset="['170','175','155','115']" 
									
									
									
									data-width="none"
									data-height="none"
									data-whitespace="nowrap"
									data-transform_idle="o:1;"
						 
									 data-transform_in="x:-50px;skX:100px;opacity:0;s:2000;e:Power4.easeInOut;" 
									 data-transform_out="s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
									data-start="1510" 
									data-splitin="none" 
									data-splitout="none" 
									data-responsive_offset="on" 

									data-elementdelay="0.05" 
									
									style="z-index: 5; white-space: nowrap; font-size: 50px; color:#fff;    font-family: 'Trirong', serif;">We help students reach their life goals
								</div>
								<div class="tp-caption NotGeneric-Title   tp-resizeme rs-parallaxlevel-0" 
						
									data-x="['left','left','left','left']" data-hoffset="['45','60','60','40']" 
									data-y="['top','top','top','top']" data-voffset="['230','215','180','170']" 
									
									data-width="none"
									data-height="none"
									data-whitespace="nowrap"
									data-transform_idle="o:1;"
						 
									 data-transform_in="x:-50px;skX:100px;opacity:0;s:2000;e:Power4.easeInOut;" 
									 data-transform_out="s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
									data-start="1810" 
									data-splitin="none" 
									data-splitout="none" 
									data-responsive_offset="on" 

									data-elementdelay="0.05" 
									
									style="z-index: 5; white-space: nowrap; font-size: 50px; color:#fff;     font-family: 'Trirong', serif;">faster and more efficiently.
								</div>

								<!-- LAYER NR. 2 -->
								<div class="tp-caption NotGeneric-CallToAction ed_btn ed_green tp-resizeme rs-parallaxlevel-0" 
									 							 
									 data-x="['left','left','left','left']" data-hoffset="['50','65','65','45']" 
									 data-y="['top','top','top','top']" data-voffset="['350','276','226','151']" 
									 
									data-whitespace="nowrap"
									data-transform_idle="o:1;"
						 
									 data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
									 data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
									 data-mask_in="x:0px;y:[100%];s:inherit;e:inherit;" 
									 data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" 
									data-start="2000" 
									data-splitin="none" 
									data-splitout="none" 
									data-responsive_offset="on" 
	
									style="z-index: 7; white-space: nowrap; ">see more
								</div>
								
						</li>
						<li data-transition="slotslide-vertical">
							
							<!-- MAIN IMAGE -->
							<img src="http://placehold.it/1920X1080"  alt="">
							<div class="ed_course_single_image_overlay"></div>

							<!-- LAYER NR. 1 -->
								<div class="tp-caption NotGeneric-Title   tp-resizeme rs-parallaxlevel-0" 

									 data-x="['left','left','left','left']" data-hoffset="['45','60','60','40']" 
									data-y="['top','top','top','top']" data-voffset="['170','175','155','115']" 
									
									
									
									data-width="none"
									data-height="none"
									data-whitespace="nowrap"
									data-transform_idle="o:1;"
						 
									 data-transform_in="x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 
									 data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" 
									 data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
									data-start="1510" 
									data-splitin="none" 
									data-splitout="none" 
									data-responsive_offset="on" 

									data-elementdelay="0.05" 
									
									style="z-index: 5; white-space: nowrap; font-size: 50px; color:#fff;     font-family: 'Trirong', serif;">When you come and we make sure
								</div>
								<div class="tp-caption NotGeneric-Title   tp-resizeme rs-parallaxlevel-0" 
						
									data-x="['left','left','left','left']" data-hoffset="['45','60','60','40']" 
									data-y="['top','top','top','top']" data-voffset="['230','215','180','170']" 
									
									data-width="none"
									data-height="none"
									data-whitespace="nowrap"
									data-transform_idle="o:1;"
						 
									 data-transform_in="x:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 
									 data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" 
									 data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
									data-start="1810" 
									data-splitin="none" 
									data-splitout="none" 
									data-responsive_offset="on" 

									data-elementdelay="0.05" 
									
									style="z-index: 5; white-space: nowrap; font-size: 50px; color:#fff;    font-family: 'Trirong', serif;">you are happy....
								</div>

								<!-- LAYER NR. 2 -->
								<div class="tp-caption NotGeneric-CallToAction ed_btn ed_green tp-resizeme rs-parallaxlevel-0" 
								 
									 
									 data-x="['left','left','left','left']" data-hoffset="['45','60','60','40']" 
									 data-y="['top','top','top','top']" data-voffset="['350','276','226','151']" 
									 
									data-whitespace="nowrap"
									data-transform_idle="o:1;"
						 
									 data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
									 data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
									 data-mask_in="x:0px;y:[100%];s:inherit;e:inherit;" 
									 data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" 
									data-start="1500" 
									data-splitin="none" 
									data-splitout="none" 
									data-responsive_offset="on" 
	
									style="z-index: 7; white-space: nowrap; ">see more
								</div>
								
						</li>
						
						<!-- SLIDE  -->
						
					</ul>				
				</div><!-- END REVOLUTION SLIDER -->
				</div><!-- END  -->
			</div><!-- END REVOLUTION SLIDER WRAPPER -->	
		</article>
	</section>
<!--Slider end-->
<!--Slider form start-->
<div class="ed_form_box">
<div class="container">
	<div class="ed_search_form">
		<form class="form-inline">
		  <div class="form-group">
			<input type="text" placeholder="Course Name" class="form-control" id="course">
		  </div>
		  <div class="form-group">
			<input type="text" placeholder="Location" class="form-control" id="location">
		  </div>
		  <div class="form-group">
			<input type="text" placeholder="Language" class="form-control" id="language">
		  </div>
		  <div class="form-group">
			<input type="text" placeholder="Type" class="form-control" id="type">
		  </div>
		  <div class="form-group">
		  <button type="button" class="btn ed_btn pull-right ed_orange">search</button>
		  </div>
		</form>
	</div>
</div>
</div>
<!--Slider form end-->
</div>

<!--Our expertise section one start -->
<div class="ed_transprentbg ed_toppadder100">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="ed_heading_top ed_toppadder50">
					<h3>Choose how you want to learn</h3>
				</div>
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="ed_populer_areas_slider">
					<div class="owl-carousel owl-theme">
						<div class="item">
							<div class="ed_item_img">
								<img src="http://placehold.it/263X263" alt="item1" class="img-responsive">
							</div>
							<div class="ed_item_description">
								<h4>Vocational Counselling</h4>
								<p>Vocational counselling is a career focused on helping people who need to find a job. Pretty obvious, obvious right?</p>
								<a href="#" class="ed_getinvolved">get involved <i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div>
						<div class="item">
							<div class="ed_item_img">
								<img src="http://placehold.it/263X263" alt="item2" class="img-responsive">
							</div>
							<div class="ed_item_description">
								<h4>Elementary School</h4>
								<p>Vocational counselling is a career focused on helping people who need to find a job. Pretty obvious, obvious right?</p>
								<a href="#" class="ed_getinvolved">get involved <i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div>
						<div class="item">
							<div class="ed_item_img">
								<img src="http://placehold.it/263X263" alt="item3" class="img-responsive">
							</div>
							<div class="ed_item_description">
								<h4>Student Guidance</h4>
								<p>Vocational counselling is a career focused on helping people who need to find a job. Pretty obvious, obvious right?</p>
								<a href="#" class="ed_getinvolved">get involved <i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div>
						<div class="item">
							<div class="ed_item_img">
								<img src="http://placehold.it/263X263" alt="item4" class="img-responsive">
							</div>
							<div class="ed_item_description">
								<h4>Psychology Tests</h4>
								<p>Vocational counselling is a career focused on helping people who need to find a job. Pretty obvious, obvious right?</p>
								<a href="#" class="ed_getinvolved">get involved <i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div>
						<div class="item">
							<div class="ed_item_img">
								<img src="http://placehold.it/263X263" alt="item1" class="img-responsive">
							</div>
							<div class="ed_item_description">
								<h4>individual attention</h4>
								<p>Vocational counselling is a career focused on helping people who need to find a job. Pretty obvious, obvious right?</p>
								<a href="#" class="ed_getinvolved">get involved <i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div>
						<div class="item">
							<div class="ed_item_img">
								<img src="http://placehold.it/263X263" alt="item2" class="img-responsive">
							</div>
							<div class="ed_item_description">
								<h4>Peer Recognition</h4>
								<p>Vocational counselling is a career focused on helping people who need to find a job. Pretty obvious, obvious right?</p>
								<a href="#" class="ed_getinvolved">get involved <i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
    </div><!-- /.container -->
</div>
<!--Our expertise section one end -->


<!--skill section start -->

<div class="ed_graysection ed_toppadder90 ed_bottompadder90">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
				<div class="skill_section">
					<h4><a href="#">See our best skills</a></h4>
					<p>We excell in multiple areas, but there are some in which we are absolutely rocking.</p>
					<span><i class="fa fa-tachometer"></i></span>
				</div>
			</div>
			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
				<div class="skill_section">
					<h4><a href="#">Recieve a sign-in sheet <i class="fa fa-long-arrow-right"></i></a></h4>
					<p>Not a member yet? You need to download this sign-in sheet and make sure you become one.</p>
					<span><i class="fa fa-file-text-o"></i></span>
				</div>
			</div>
        </div>
	</div>
</div>
<!--skill section end -->
<!--video_section Section three start -->
<div class="ed_parallax_section">
<div class="ed_img_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-12">
				<div class="ed_video_section">
					<div class="embed-responsive embed-responsive-16by9">
						<div class="ed_video">
							<img src="http://placehold.it/544X334" style="cursor:pointer"  alt="1" />
							<div class="ed_img_overlay">
								<a href="#"><i class="fa fa-chevron-right"></i></a>
							</div>
						</div>
						<iframe id="educo_video" class="embed-responsive-item" src="https://www.youtube.com/embed/8mb-0qbq984" allowfullscreen></iframe>
					</div>
				</div>
			</div>
			<div class="col-lg-6 col-md-6 col-sm-12">
				<div class="ed_video_section_discription">
					<h4>Daily life of studying at Educo</h4>
					<p>Nam cursus imperdiet elit. Fusce sollicitudin eget nulla in condimentum. Nullam dignissim id magna non tempus. Vivamus molestie nulla nec pharetra dignissim. Suspendisse auctor nisi et neque vehicula pulvinar. Quisque quis tempus magna. Quisque sed luctus nunc sapien.</p>
					<span><a href="#" class="btn ed_btn ed_orange">see more</a></span>
				</div>
			</div>
		</div>
	</div>
</div>
<!--video_section Section three end -->
<!-- Most recomended Courses Section four start -->
<div class="ed_transprentbg ed_toppadder80 ed_bottompadder80">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="ed_heading_top ed_bottompadder80">
					<h3>Learner recommended courses</h3>
				</div>
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="ed_mostrecomeded_course_slider ed_mostrecomededcourseslider">
					<div id="owl-demo3" class="owl-carousel owl-theme">
						<div class="item">
							<div class="ed_item_img">
								<img src="http://placehold.it/263X263" alt="item1" class="img-responsive">
							</div>
							<div class="ed_item_description ed_most_recomended_data">
									<h4><a href="course_single.html">Project Learning </a><span>�25</span></h4>
									<div class="row">
										<div class="ed_rating">
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
												<div class="row">
													<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
														<div class="ed_stardiv">
															<div class="star-rating"><span style="width:80%;"></span></div>
														</div>
													</div>
													<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
														<div class="row">
															<p>(5 review)</p>
														</div>
													</div>
												</div>
											</div>
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
												<div class="ed_views">
												<i class="fa fa-users"></i>
												<span>35 students</span>
												</div>
											</div>
										</div>
									</div>
									<div class="course_detail">
										<div class="course_faculty">
											<img src="http://placehold.it/32X32" alt=""> <a href="instructor_dashboard.html">Joanna Simpson</a>
										</div>
									</div>
									<p>Project-Based Learning is a flexible tool for framing given academic standards into curriculum flexible tool for framing.</p>
									<a href="course_single.html" class="ed_getinvolved">get involved <i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div>
						<div class="item">
							<div class="ed_item_img">
								<img src="http://placehold.it/263X263" alt="item1" class="img-responsive">
							</div>
							<div class="ed_item_description ed_most_recomended_data">
									<h4><a href="course_single.html">Billing Seminar</a><span>free</span></h4>
									<div class="row">
										<div class="ed_rating">
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
												<div class="row">
													<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
														<div class="ed_stardiv">
															<div class="star-rating"><span style="width:80%;"></span></div>
														</div>
													</div>
													<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
														<div class="row">
															<p>(10 review)</p>
														</div>
													</div>
												</div>
											</div>
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
												<div class="ed_views">
												<i class="fa fa-users"></i>
												<span>55 students</span>
												</div>
											</div>
										</div>
									</div>
									<div class="course_detail">
										<div class="course_faculty">
											<img src="http://placehold.it/32X32" alt=""> <a href="instructor_dashboard.html">DESPERATE SCOTT</a>
										</div>
									</div>
									<p>Project-Based Learning is a flexible tool for framing given academic standards into curriculum flexible tool for framing.</p>
									<a href="course_single.html" class="ed_getinvolved">get involved <i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div>
						<div class="item">
							<div class="ed_item_img">
								<img src="http://placehold.it/263X263" alt="item1" class="img-responsive">
							</div>
							<div class="ed_item_description ed_most_recomended_data">
									<h4><a href="course_single.html">User Experience Jam </a><span>�38</span></h4>
									<div class="row">
										<div class="ed_rating">
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
												<div class="row">
													<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
														<div class="ed_stardiv">
															<div class="star-rating"><span style="width:80%;"></span></div>
														</div>
													</div>
													<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
														<div class="row">
															<p>(9 review)</p>
														</div>
													</div>
												</div>
											</div>
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
												<div class="ed_views">
												<i class="fa fa-users"></i>
												<span>60 students</span>
												</div>
											</div>
										</div>
									</div>
									<div class="course_detail">
										<div class="course_faculty">
											<img src="http://placehold.it/32X32" alt=""> <a href="instructor_dashboard.html">MIKE TUSSLE</a>
										</div>
									</div>
									<p>Project-Based Learning is a flexible tool for framing given academic standards into curriculum flexible tool for framing.</p>
									<a href="course_single.html" class="ed_getinvolved">get involved <i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div>
						<div class="item">
							<div class="ed_item_img">
								<img src="http://placehold.it/263X263" alt="item1" class="img-responsive">
							</div>
							<div class="ed_item_description ed_most_recomended_data">
									<h4><a href="course_single.html">Girls On Rails </a><span>free</span></h4>
									<div class="row">
										<div class="ed_rating">
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
												<div class="row">
													<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
														<div class="ed_stardiv">
															<div class="star-rating"><span style="width:80%;"></span></div>
														</div>
													</div>
													<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
														<div class="row">
															<p>(8 review)</p>
														</div>
													</div>
												</div>
											</div>
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
												<div class="ed_views">
												<i class="fa fa-users"></i>
												<span>45 students</span>
												</div>
											</div>
										</div>
									</div>
									<div class="course_detail">
										<div class="course_faculty">
											<img src="http://placehold.it/32X32" alt=""> <a href="instructor_dashboard.html"> JAMES MARCO</a>
										</div>
									</div>
									<p>Project-Based Learning is a flexible tool for framing given academic standards into curriculum flexible tool for framing.</p>
									<a href="course_single.html" class="ed_getinvolved">get involved <i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div>
						<div class="item">
							<div class="ed_item_img">
								<img src="http://placehold.it/263X263" alt="item1" class="img-responsive">
							</div>
							<div class="ed_item_description ed_most_recomended_data">
									<h4><a href="course_single.html">Coding Seminar</a><span>free</span></h4>
									<div class="row">
										<div class="ed_rating">
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
												<div class="row">
													<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
														<div class="ed_stardiv">
															<div class="star-rating"><span style="width:80%;"></span></div>
														</div>
													</div>
													<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
														<div class="row">
															<p>(7 review)</p>
														</div>
													</div>
												</div>
											</div>
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
												<div class="ed_views">
												<i class="fa fa-users"></i>
												<span>31 students</span>
												</div>
											</div>
										</div>
									</div>
									<div class="course_detail">
										<div class="course_faculty">
											<img src="http://placehold.it/32X32" alt=""> <a href="instructor_dashboard.html"> ANDRE HOUSE</a>
										</div>
									</div>
									<p>Project-Based Learning is a flexible tool for framing given academic standards into curriculum flexible tool for framing.</p>
									<a href="course_single.html" class="ed_getinvolved">get involved <i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div>
						<div class="item">
							<div class="ed_item_img">
								<img src="http://placehold.it/263X263" alt="item1" class="img-responsive">
							</div>
							<div class="ed_item_description ed_most_recomended_data">
									<h4><a href="course_single.html">Javascript Campus</a><span>�60</span></h4>
									<div class="row">
										<div class="ed_rating">
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
												<div class="row">
													<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
														<div class="ed_stardiv">
															<div class="star-rating"><span style="width:80%;"></span></div>
														</div>
													</div>
													<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
														<div class="row">
															<p>(1 review)</p>
														</div>
													</div>
												</div>
											</div>
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
												<div class="ed_views">
												<i class="fa fa-users"></i>
												<span>18 students</span>
												</div>
											</div>
										</div>
									</div>
									<div class="course_detail">
										<div class="course_faculty">
											<img src="http://placehold.it/32X32" alt=""> <a href="instructor_dashboard.html"> FRANK PASCAL</a>
										</div>
									</div>
									<p>Project-Based Learning is a flexible tool for framing given academic standards into curriculum flexible tool for framing.</p>
									<a href="course_single.html" class="ed_getinvolved">get involved <i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
    </div><!-- /.container -->
</div>
<!--Most recomended Courses Section four end -->
<!--Latest news start -->
<div class="ed_graysection ed_toppadder80 ed_bottompadder80">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 ed_bottompadder80">
				<div class="ed_heading_top">
					<h3>Latest News</h3>
				</div>
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="ed_latest_news_slider">
					<div id="owl-demo2" class="owl-carousel owl-theme">
						<div class="item">
							<div class="ed_item_description">
								<h4>Officially the best</h4>
								<p>Just in case there is anyone looking for it, new expertise to our knowledge base to make you happy as well.</p>
								<a href="">read more <i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div>
						<div class="item">
							<div class="ed_item_description">
								<h4>Redesigned website</h4>
								<p>Just in case there is anyone looking for it, new expertise to our knowledge base to make you happy as well.</p>
								<a href="">read more <i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div>
						<div class="item">
							<div class="ed_item_description">
								<h4>We are launching</h4>
								<p>Just in case there is anyone looking for it, new expertise to our knowledge base to make you happy as well.</p>
								<a href="">read more <i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div>
						<div class="item">
							<div class="ed_item_description">
								<h4>Officially the best</h4>
								<p>Just in case there is anyone looking for it, new expertise to our knowledge base to make you happy as well.</p>
								<a href="">read more <i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div>
						<div class="item">
							<div class="ed_item_description">
								<h4>Redesigned website</h4>
								<p>Just in case there is anyone looking for it, new expertise to our knowledge base to make you happy as well.</p>
								<a href="">read more <i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div> 
					</div>
				</div>
			</div>
		</div>
    </div><!-- /.container -->
</div>
<!--Latest news end -->
<!--Newsletter Section six start-->
<div class="ed_newsletter_section">
<div class="ed_img_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12">
				<div class="row">
					<div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
						<div class="ed_newsletter_section_heading">
							<h4>Let us inform you about everything important directly.</h4>
						</div>
					</div>
					<div class="col-lg-5 col-md-5 col-sm-6 col-xs-6 col-lg-offset-0 col-md-offset-0 col-sm-offset-3 col-xs-offset-3">
						<div class="row">
							<div class="ed_newsletter_section_form">
								<form class="form">
									<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
										<input class="form-control" type="text" placeholder="Newsletter Email" />
									</div>
									<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
										<button class="btn ed_btn ed_green">confirm</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
        </div>
	</div>
</div>
<!--Newsletter Section six end-->
<!--Footer Top section start-->
<div class="ed_footer_wrapper">
	<div class="ed_footer_top">
		<div class="container">
			<div class="row">
				<div class="col-lg-4 col-md-4 col-sm-12">
					<div class="widget text-widget">
						<p><a href="index.html"><img src="images/footer/F_Logo.png" alt="Footer Logo" /></a></p>
						<p>Edution is an outstanding PSD template targeting educational institutions, helping them establish strong identity on the internet without any real developing knowledge.
						</p>
						<div class="ed_sociallink">
						<ul>
							<li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
							<li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Google+"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
							<li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
							<li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Linkedin"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
							<li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Whatsapp"><i class="fa fa-whatsapp" aria-hidden="true"></i></a></li>
						</ul>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-12">
					<div class="widget text-widget">
						<h4 class="widget-title">find us</h4>
						<p><i class="fa fa-safari"></i>Wimbledon Street 42a, 45290 Wimbledon, <br/>United Kingdom</p>
						<p><i class="fa fa-envelope-o"></i><a href="#">info@edutioncollege.gov.co.uk</a> <a href="#">public@edutioncollege.gov.co.uk</a></p>
						<p><i class="fa fa-phone"></i> 1-220-090-080</p>
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-12">
					<div class="widget text-widget">
						<h4 class="widget-title">social media</h4>
						<p><strong>@education  </strong> How many students do you educate monthly? Open <a href=""> http://t.co/KFDdzLSD9</a><br/>2 days ago</p>
						
						<p><strong>@educationUK  </strong> Web Design that works. Have a look at this masterpiece. <a href="">http://t.co/9j8DH93zrO</a><br/>5 days ago</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--Footer Top section end-->
<!--Footer Bottom section start-->
<div class="ed_footer_bottom">
	<div class="container">
		<div class="col-lg-12 col-md-12 col-sm-12">
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
				<div class="ed_copy_right">
					<p>&copy; Copyright 2017, All Rights Reserved, <a href="#">EDUCO</a></p>
				</div>
			</div>
			<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
				<div class="ed_footer_menu">
						<ul>
							<li><a href="index.html">home</a></li>
							<li><a href="private_policy.html">private policy</a></li>
							<li><a href="about.html">about</a></li>
							<li><a href="contact.html">contact us</a></li>
						</ul>
				</div>
			</div>
		</div>
		</div>
	</div>
</div>
<!--Footer Bottom section end-->
</div>
<!--Page main section end-->
<!--main js file start--> 
<script type="text/javascript" src="js/jquery-1.12.2.js"></script> 
<script type="text/javascript" src="js/bootstrap.js"></script> 
<script type="text/javascript" src="js/modernizr.js"></script> 
<script type="text/javascript" src="js/owl.carousel.js"></script>
<script type="text/javascript" src="js/smooth-scroll.js"></script> 
<script type="text/javascript" src="js/plugins/revel/jquery.themepunch.tools.min.js"></script>
<script type="text/javascript" src="js/plugins/revel/jquery.themepunch.revolution.min.js"></script>
<script type="text/javascript" src="js/plugins/revel/revolution.extension.layeranimation.min.js"></script>
<script type="text/javascript" src="js/plugins/revel/revolution.extension.navigation.min.js"></script>
<script type="text/javascript" src="js/plugins/revel/revolution.extension.slideanims.min.js"></script>
<script type="text/javascript" src="js/plugins/countto/jquery.countTo.js"></script>
<script type="text/javascript" src="js/plugins/countto/jquery.appear.js"></script>
<script type="text/javascript" src="js/custom.js"></script> 

<!--main js file end-->
</body>
</html>