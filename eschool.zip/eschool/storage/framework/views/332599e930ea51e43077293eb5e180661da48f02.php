
<!--header end -->
<!--Breadcrumb start-->
<?php $__env->startSection('index_body'); ?>
<div class="ed_pagetitle">
<div class="ed_img_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-4 col-sm-6">
				<div class="page_title">
					<h2>Évènement</h2>
				</div>
			</div>
			<div class="col-lg-6 col-md-8 col-sm-6">
				<ul class="breadcrumb">
					<li><a href="<?php echo e(url('home')); ?>">Accueil</a></li>
					<li><i class="fa fa-chevron-left"></i></li>
					<li><a href="<?php echo e(url('events')); ?>">Évènements</a></li>
					<li><i class="fa fa-chevron-left"></i></li>
					<li><a href="<?php echo e(url('event_single')); ?>">Évenement</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<!--Breadcrumb end-->
<!--Single content start-->
<div class="ed_single_wrapper ed_toppadder80 ed_bottompadder80">
	<div class="container">
		<div class="row">
			<div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
				<div class="ed_event_single_item">
					<div class="ed_event_single_image">
						<img src="http://placehold.it/846X450" alt="event image" />
					</div>
					<div class="ed_event_single_info">
						<h2>Summer Javascript Course</h2>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent vehicula mauris ac facilisis congue. Fusce sem enim, rhoncus volutpat condimentum ac, placerat semper ligula. Suspendisse in viverra justo, eu placerat urna. Vestibulum blandit diam suscipit nibh mattis ullamcorper. Nullam a condimentum nulla, ut facilisis enim. Aliquam sagittis ipsum ex, sed luctus augue venenatis ut. Fusce at rutrum tellus, ac elementum neque. In nec velit orci. Etiam purus felis, pellentesque sit amet tincidunt at, iaculis quis erat. Morbi imperdiet sodales sapien nec rhoncus. Donec placerat mi et libero iaculis, id maximus est vestibulum. Etiam augue augue, auctor at ornare eget, porta ac nisl. Aliquam et mattis dolor, et aliquet ligula. Sed ultricies posuere magna elementum laoreet. Suspendisse elementum sagittis nisl, id pellentesque purus auctor finibus. Donec elementum quam est, a condimentum diam tempor ac. Sed quis magna lobortis, pulvinar est at, commodo mauris. Nunc in mollis erat. Integer aliquet orci non auctor pretium. Pellentesque eu nisl augue. Curabitur vitae est ut sem luctus tristique. Suspendisse euismod sapien facilisis tellus aliquam pellentesque.</p>
						<p>Nam id ligula tristique, porta dolor ac, pretium leo. Maecenas scelerisque vulputate dapibus. Quisque sodales tincidunt sapien, eu consequat erat tempus et. Nullam ipsum est, interdum quis posuere sed, imperdiet quis nisi. Proin quis justo est. Vestibulum imperdiet leo sit amet tortor suscipit, id cursus ligula pharetra. Donec in enim augue. Maecenas dolor odio, pulvinar sit amet justo id, pellentesque gravida ligula. Nullam ultricies aliquet nulla, vel viverra dolor auctor et. Donec vel lacus tristique, venenatis diam id, accumsan odio. Integer at velit mauris. Vestibulum mattis, metus et hendrerit porttitor, nulla ex volutpat ante, in gravida quam ipsum in elit.</p>
					</div>
				</div>			
			</div>
<!--Sidebar Start-->
			<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
				<div class="sidebar_wrapper">
					<aside class="widget widget_button">
						<a href="#" data-toggle="modal" data-target="#invitation_form" class="ed_btn ed_green">invitez un ami</a>
						<div class="modal fade" id="invitation_form">
							<div class="modal-dialog">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">x</span></button>
										<h4 class="modal-title">Invitation....</h4>
									</div>
									<form>
									<div class="modal-body">
										<div class="form-group">
											<label class="control-label"> Nom:</label>
											<input type="text" class="form-control" >
										</div>
                                        <div class="form-group">
											<label class="control-label">Email de l'invité:</label>
											<input type="email" class="form-control" >
										</div>
										<div class="form-group">
											<label  class="control-label">Message:</label>
											<textarea rows="4" cols="50" class="form-control"></textarea>
										</div>
									</div>
									<div class="modal-footer">
										<button type="Submit" class="btn ed_btn ed_orange">Envoyer</button>
									</div>
									</form>
								</div><!-- /.modal-content -->
							</div><!-- /.modal-dialog -->
						</div><!-- /.modal -->
					</aside>
					<aside class="widget widget_calendar">
						<div class="jquery-calendar"></div>
					</aside>
					<aside class="widget widget_categories">
						<h4 class="widget-title">Events Documented</h4>
						<ul>
							<li><a href="#"><i class="fa fa-chevron-right"></i> Physics Championship</a></li>
							<li><a href="#"><i class="fa fa-chevron-right"></i> The First Color Run</a></li>
							<li><a href="#"><i class="fa fa-chevron-right"></i> Tea For Everyone</a></li>
							<li><a href="#"><i class="fa fa-chevron-right"></i> Catrina Charity</a></li>
							<li><a href="#"><i class="fa fa-chevron-right"></i> Edution Orchestra</a></li>
							<li><a href="#"><i class="fa fa-chevron-right"></i> Welcome Party</a></li>
						</ul>
					</aside>
				</div>
			</div>
<!--Sidebar End-->
		</div>
	</div>    
</div>
<!--Single content end-->
<!--Section fifteen Contact form start-->
<div class="ed_event_single_contact_address ed_toppadder70 ed_bottompadder70">
	<div class="container">
		<div class="col-lg-6 col-md-6 col-sm-6">
			<div class="row">
				<div class="ed_event_single_address_info ed_toppadder40 ed_bottompadder40">
					<h4 class="ed_bottompadder30">Details</h4>
					<p>Date & Time: <span>September 17 @ 7:00 am - 9:00 am </span></p>
					<p>Organizer: <span>James Marco</span></p>
					<p>Phone: <span>1-220-090-080</span></p>
					<p>Email: <a href="#">info@edutioncollege.gov.co.uk</a></p>
					<p>Website: <a href="#">http://www.edutioncollege.gov.co.uk</a></p>
					<span class="ed_toppadder40"><a href="#">Google Map Link <i class="fa fa-hand-o-right"></i></a></span>
				</div>
			</div>
		</div>
		<div class="col-lg-6 col-md-6 col-sm-6">
			<div class="row">
				<div class="ed_event_single_address_map">
					<div id="map"></div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--Section fifteen Contact form start-->
<?php $__env->stopSection(); ?>
<script>
	var map;
    $(document).ready(function(){
      map = new GMaps({
        el: '#map',
		zoom: 16,
        lat: -12.043333,
        lng: -77.028333,
		scrollwheel: false,
		draggable:false,
		zoomControl: false,
		navigationControl: false,
		mapTypeControl: false,
		scaleControl: false,
		disableDoubleClickZoom: true,
		streetViewControl : false,
		overviewMapControl: false,
		panControl : false
      });
      map.addMarker({
        lat: -12.042,
        lng: -77.028333,
        title: 'Marker with InfoWindow',
        infoWindow: {
          content: '<p>Event Place</p>'
        }
      });
    });
  </script>
<!--main js file end-->

<?php echo $__env->make('checkout-template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>