<!--header end -->
<!--Breadcrumb start-->
<?php $__env->startSection('index_body'); ?>
<div class="ed_pagetitle">
<div class="ed_img_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-4 col-sm-6">
				<div class="page_title">
					<h2>Cours</h2>
				</div>
			</div>
			<div class="col-lg-6 col-md-8 col-sm-6">
				<ul class="breadcrumb">
					<li><a href="<?php echo e(url('home')); ?>">Accueil</a></li>
					<li><i class="fa fa-chevron-left"></i></li>
					<li><a href="<?php echo e(url('courses')); ?>">Cours</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<!--Breadcrumb end-->
<!-- Section eleven start -->
<div class="ed_courses ed_toppadder80 ed_bottompadder80">
	<div class="container">
		<div class="row">
		  <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php
			$auter=DB::table('enrolement')->where('course_id','=',$course->course_id)->count();
			$auter=DB::table('users')->where('id','=',$course->prof_id)->first();

			?>
		<div class="col-lg-9 col-md-9 col-sm-12">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
					<div class="ed_mostrecomeded_course">
						<div class="ed_item_img">
							<img src="http://placehold.it/379X379" alt="item1" class="img-responsive">
						</div>
						<div class="ed_item_description ed_most_recomended_data">
							<h4><a href="<?php echo e(url('course_single')); ?>"><?php echo e($course->course_title); ?>  </a><span>£<?php echo e($course->price); ?></span></h4>
							<div class="row">
								<div class="ed_rating">
									<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
										<div class="row">
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
												<div class="ed_stardiv">
													<div class="star-rating"><span style="width:80%;"></span></div>
												</div>
											</div>
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
												<div class="row">
													<p>(5 review)</p>
												</div>
											</div>
										</div>
									</div>
									<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
										<div class="ed_views">
										<i class="fa fa-users"></i>
										<span><?php echo $students_number; ?> etudiants</span>
										</div>
									</div>
								</div>
							</div>
							<div class="course_detail">
								<div class="course_faculty">
									<img src="http://placehold.it/32X32" alt=""> <a href="<?php echo e(url('instructor_dashboard')); ?>"><?php echo e($auter); ?>}</a>
								</div>
							</div>
							<p><?php echo e($course->description); ?></p>
							<a href="<?php echo e(url('course_single')); ?>" class="ed_getinvolved">participer<i class="fa fa-long-arrow-right"></i></a>
						</div>
					</div>
				</div>
				
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<div class="col-lg-12">
					<div class="ed_blog_bottom_pagination">
						<nav>
							<ul class="pagination">
								<li><a href="#">1</a></li>
								<li><a href="#">2</a></li>
								<li><a href="#">3</a></li>
								<li class="active"><a href="#">Next <span class="sr-only">(current)</span></a></li>
							</ul>
						</nav>
					</div>
				</div>
			</div>
		</div>
	<!--Sidebar Start-->
		<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
			<div class="sidebar_wrapper_upper">
				<div class="sidebar_wrapper">
					<aside class="widget widget_search">
						<div class="input-group">
							<input type="text" class="form-control" placeholder="Search...">
							<span class="input-group-btn">
								<button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
							</span>
						</div>
					</aside>
					<aside class="widget widget_categories">
						<h4 class="widget-title">course Categories</h4>
						<ul>
							<li><a href="#"><i class="fa fa-chevron-right"></i> languages</a></li>
							<li><a href="#"><i class="fa fa-chevron-right"></i> digital literacy</a></li>
							<li><a href="#"><i class="fa fa-chevron-right"></i> business</a></li>
							<li><a href="#"><i class="fa fa-chevron-right"></i> it skills</a></li>
							<li><a href="#"><i class="fa fa-chevron-right"></i> health literacy</a></li>
							<li><a href="#"><i class="fa fa-chevron-right"></i> photography</a></li>
							<li><a href="#"><i class="fa fa-chevron-right"></i> spoken</a></li>
						</ul>
					</aside>
					<aside class="widget widget_categories">
						<h4 class="widget-title">course type</h4>
						<ul>
							<li><a href="#"><i class="fa fa-chevron-right"></i> all</a></li>
							<li><a href="#"><i class="fa fa-chevron-right"></i> paid</a></li>
							<li><a href="#"><i class="fa fa-chevron-right"></i> free</a></li>
						</ul>
					</aside>
					<aside class="widget widget_categories">
						<h4 class="widget-title">course certification</h4>
						<ul>
							<li><a href="#"><i class="fa fa-chevron-right"></i> diploma</a></li>
							<li><a href="#"><i class="fa fa-chevron-right"></i> graduation</a></li>
							<li><a href="#"><i class="fa fa-chevron-right"></i> post graduation</a></li>
						</ul>
					</aside>
					<aside class="widget widget_tag_cloud">
						<h4 class="widget-title">Search by Tags</h4>
							<a href="#" class="ed_btn ed_orange">university</a>
							<a href="#" class="ed_btn ed_orange">skill</a>
							<a href="#" class="ed_btn ed_orange">tests</a>
							<a href="#" class="ed_btn ed_orange">exams</a>
							<a href="#" class="ed_btn ed_orange">elementary school</a>
							<a href="#" class="ed_btn ed_orange">college</a>
							<a href="#" class="ed_btn ed_orange">edution</a>
					</aside>
				</div>
			</div>
		</div>
<!--Sidebar End-->
		</div>
    </div><!-- /.container -->
</div>
<!-- Section eleven end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('checkout-template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>