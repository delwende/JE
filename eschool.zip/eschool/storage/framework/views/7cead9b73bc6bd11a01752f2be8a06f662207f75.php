<!DOCTYPE html>
<!-- 
Template Name: Educo
Version: 3.0.0
Author: Kamleshyadav
Website: http://himanshusofttech.com/
Purchase: http://themeforest.net/user/kamleshyadav
-->
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<!--<![endif]-->

<!-- Begin Head -->
<head>
<meta charset="utf-8" />
<title>EDUWakat</title>
<meta content="width=device-width, initial-scale=1.0" name="viewport" />
<meta name="description"  content="EDUWakat"/>
<meta name="keywords" content="cours, html , Education, Web development, développement Mobile " />
<meta name="author"  content="Jean_Eliane"/>
<meta name="MobileOptimized" content="320" />

<!--srart theme style -->
<link href="css/main.css" rel="stylesheet" type="text/css"/>
<!-- end theme style -->
<!-- favicon links -->
<link rel="shortcut icon" type="image/png" href="images/header/favicon.png" />
</head>
<body>
<!--Page main section start-->
<div id="educo_wrapper">
<!--Header start-->
<header id="ed_header_wrapper">
	<div class="ed_header_top">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12">
					<p>Bienvenue à EDUWakat</p>
					<div class="ed_info_wrapper">
						<a href="#" id="login_button">Connectez-vous</a>
							<div id="login_one" class="ed_login_form">
								<h3>log in</h3>
								<form class="form">
									<div class="form-group">
										<label class="control-label">Email :</label>
										<input type="text" class="form-control" >
									</div>
									<div class="form-group">
										<label  class="control-label">Mot de passe :</label>
										<input type="password" class="form-control">
									</div>
									<div class="form-group">
										<button type="submit">login</button>
										<a href="<?php echo e(url('signup')); ?>">S'inscrire</a>	
									</div>
								</form>
							</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="ed_header_bottom">
		<div class="container">
			<div class="row">
				<div class="col-lg-2 col-md-2 col-sm-2">
					<div class="educo_logo"> <a href="<?php echo e(url('home')); ?>"><img src="images/header/Logo.png" alt="logo" /></a> </div>
				</div>
				<div class="col-lg-8 col-md-8 col-sm-8">
					<div class="edoco_menu_toggle navbar-toggle" data-toggle="collapse" data-target="#ed_menu">Menu <i class="fa fa-bars"></i>
					</div>
					<div class="edoco_menu">
						<ul class="collapse navbar-collapse" id="ed_menu">
							<li><a href="<?php echo e(url('home')); ?>">Accueil</a></li>
							
							
							<li><a href="<?php echo e(url('events')); ?>">évènements</a>
								<ul class="sub-menu">
									<li><a href="#">Bootcamps</a></li>
									<li><a href="#">Hackton</a></li>
								</ul>
							</li>
							<li><a href="#">Cours</a>
								<ul class="sub-menu">
									<li><a href="<?php echo e(url('course_sidebar')); ?>"> Développement Web</a></li>
									<li><a href="<?php echo e(url('course_sidebar')); ?>">Dévelopment Mobile </a></li>
									<li><a href="<?php echo e(url('course_sidebar')); ?>">Business Management</a></li>
									<li><a href="<?php echo e(url('course_sidebar')); ?>">Langues</a></li>
                                    <li><a href="<?php echo e(url('course_sidebar')); ?>">Motivations </a></li>
								</ul>
							</li>
							<li><a href="<?php echo e(url('instructor')); ?>">Professeurs</a>
								<!--<ul class="sub-menu">
									<li><a href="instructor.html">all instructor</a></li>
									<li><a href="instructor_dashboard.html">instructor dashboard</a></li>
									<li><a href="dashboard.html">student dashboard</a></li>
									<li><a href="become_teacher.html">Become teacher</a></li>
									<li><a href="pricing_table.html">pricing table</a></li>
									<li><a href="cart.html">cart</a></li>
									<li><a href="checkout.html">checkout</a></li>
									<li><a href="purchase_course.html">purchase course</a></li>
									<li><a href="not_found.html">404 error</a></li>
								</ul>!-->
							</li>
                            <div class="col-lg-2 col-md-2 col-sm-2">
                            <li> <a href="<?php echo e(url('cart')); ?>"> <i class="fa fa-shopping-cart" aria-hidden="true"> Panier</i></a></li>
                                </div>
							<li><a href="<?php echo e(url('contact')); ?>">Contacts</a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2">
					<div class="educo_call"><i class="fa fa-phone"></i><a href="#">1-220-090</a></div>
				</div>
			</div>
		</div>
    </div>
</header>
<!--header end -->
<div class="ed_slider_form_section">
<!--Slider start-->
	<section class="ed_mainslider">
		<article class="content">
			<div class="rev_slider_wrapper">			
				<!-- START REVOLUTION SLIDER 5.0 auto mode -->
				<div id="rev_slider_4_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" data-alias="classicslider1" style="margin:0px auto;background-color:transparent;padding:0px;margin-top:0px;margin-bottom:0px;">
				<div id="rev_slider" class="rev_slider "  data-version="5.0">
					<ul>	
						<!-- SLIDE  -->
						<li data-transition="3dcurtain-horizontal">
							
							<!-- MAIN IMAGE -->
							<img src="http://placehold.it/1920X1080"  alt="">							
							<div class="ed_course_single_image_overlay"></div>
							<!-- LAYER NR. 1 -->
								<div class="tp-caption NotGeneric-Title   tp-resizeme rs-parallaxlevel-0" 

									 data-x="['left','left','left','left']" data-hoffset="['45','60','60','40']" 
									data-y="['top','top','top','top']" data-voffset="['170','175','155','115']" 
									
									
									
									data-width="none"
									data-height="none"
									data-whitespace="nowrap"
									data-transform_idle="o:1;"
						 
									 data-transform_in="y:[-100%];z:0;rZ:35deg;sX:1;sY:1;skX:0;skY:0;s:2000;e:Power4.easeInOut;" 
									 data-transform_out="s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
									 data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
									data-start="1510" 
									data-splitin="chars" 
									data-splitout="none" 
									data-responsive_offset="on" 

									data-elementdelay="0.05" 
									
									style="z-index: 5; white-space: nowrap; font-size: 50px; color:#fff;     font-family: 'Roboto Slab', serif;">Codez désormais dans votre langue maternelle
								</div>
								<div class="tp-caption NotGeneric-Title   tp-resizeme rs-parallaxlevel-0" 
						
									data-x="['left','left','left','left']" data-hoffset="['45','60','60','40']" 
									data-y="['top','top','top','top']" data-voffset="['230','215','180','170']" 
									
									data-width="none"
									data-height="none"
									data-whitespace="nowrap"
									data-transform_idle="o:1;"
						 
									 data-transform_in="y:[100%];z:0;rZ:-35deg;sX:1;sY:1;skX:0;skY:0;s:2000;e:Power4.easeInOut;" 
									 data-transform_out="s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
									 data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
									data-start="1810" 
									data-splitin="chars" 
									data-splitout="none" 
									data-responsive_offset="on" 

									data-elementdelay="0.05" 
									
									style="z-index: 5; white-space: nowrap; font-size: 50px; color:#fff;     font-family: 'Roboto Slab', serif;">Apprenez  un talent  aujourd'hui.
								</div>

								<!-- LAYER NR. 2 -->
								<div class="tp-caption NotGeneric-CallToAction ed_btn ed_green tp-resizeme rs-parallaxlevel-0" 
									 
									  data-x="['left','left','left','left']" data-hoffset="['45','60','60','40']" 
									 data-y="['top','top','top','top']" data-voffset="['350','276','226','151']" 
									 
									data-whitespace="nowrap"
									data-transform_idle="o:1;"
						 
									 data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
									 data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
									 data-mask_in="x:0px;y:[100%];s:inherit;e:inherit;" 
									 data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" 
									data-start="1500" 
									data-splitin="none" 
									data-splitout="none" 
									data-responsive_offset="on" 
	
									style="z-index: 7; white-space: nowrap; "><a href="<?php echo e(url('become_teacher')); ?>" >Ouvrir un cour</a>
								</div>
								
						</li>
						<li data-transition="3dcurtain-vertical">
							
							<!-- MAIN IMAGE -->
							<img src="http://placehold.it/1920X1080"  alt="">							
<div class="ed_course_single_image_overlay"></div>
							<!-- LAYER NR. 1 -->
								<div class="tp-caption NotGeneric-Title   tp-resizeme rs-parallaxlevel-0" 

									 data-x="['left','left','left','left']" data-hoffset="['45','60','60','40']" 
									data-y="['top','top','top','top']" data-voffset="['170','175','155','115']" 
									
									
									
									data-width="none"
									data-height="none"
									data-whitespace="nowrap"
									data-transform_idle="o:1;"
						 
									 data-transform_in="x:[105%];z:0;rX:45deg;rY:0deg;rZ:90deg;sX:1;sY:1;skX:0;skY:0;s:2000;e:Power4.easeInOut;" 
									 data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
									 data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
									 data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" 
									data-start="1000" 
									data-splitin="chars" 
									data-splitout="none" 
									data-responsive_offset="on" 

									data-elementdelay="0.05" 
									
									style="z-index: 5; white-space: nowrap; font-size: 50px; color:#fff;     font-family: 'Roboto Slab', serif;">Apprenez désormais tout dans votre langue
								</div>
								<div class="tp-caption NotGeneric-Title   tp-resizeme rs-parallaxlevel-0" 
						
									data-x="['left','left','left','left']" data-hoffset="['45','60','60','40']" 
									data-y="['top','top','top','top']" data-voffset="['230','215','180','170']" 
									
									data-width="none"
									data-height="none"
									data-whitespace="nowrap"
									data-transform_idle="o:1;"
						 
									 data-transform_in="x:[105%];z:0;rX:45deg;rY:0deg;rZ:90deg;sX:1;sY:1;skX:0;skY:0;s:2000;e:Power4.easeInOut;" 
									 data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
									 data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
									 data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" 
									data-start="1000" 
									data-splitin="chars" 
									data-splitout="none" 
									data-responsive_offset="on" 

									data-elementdelay="0.05" 
									
									style="z-index: 5; white-space: nowrap; font-size: 50px; color:#fff;     font-family: 'Roboto Slab', serif;">Et devenez plus productif....
								</div>

								<!-- LAYER NR. 2 -->
								<div class="tp-caption NotGeneric-CallToAction ed_btn ed_green tp-resizeme rs-parallaxlevel-0" 
									 
									 data-x="['left','left','left','left']" data-hoffset="['45','60','60','40']" 
									 data-y="['top','top','top','top']" data-voffset="['350','276','226','151']" 
									 
									data-whitespace="nowrap"
									data-transform_idle="o:1;"
						 
									 data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
									 data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
									 data-mask_in="x:0px;y:[100%];s:inherit;e:inherit;" 
									 data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" 
									data-start="1500" 
									data-splitin="none" 
									data-splitout="none" 
									data-responsive_offset="on" 
	
									style="z-index: 7; white-space: nowrap; "><a href="<?php echo e(url('become_teacher')); ?>">Ouvrez un cours</a>
								</div>
								
						</li>
						
						<!-- SLIDE  -->
						
					</ul>				
				</div><!-- END REVOLUTION SLIDER -->
				</div><!-- END  -->
			</div><!-- END REVOLUTION SLIDER WRAPPER -->	
		</article>
	</section>
<!--Slider end-->
<!--Slider form start-->

    </div>
<!--Slider form end-->

    <?php echo $__env->yieldContent('index_body'); ?>

<!--Newsletter Section six start-->
<div class="ed_newsletter_section">
<div class="ed_img_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12">
				<div class="row">
					<div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
						<div class="ed_newsletter_section_heading">
							<h4>Restez au parfun de nos nouvels .</h4>
						</div>
					</div>
					<div class="col-lg-5 col-md-5 col-sm-6 col-xs-6 col-lg-offset-0 col-md-offset-0 col-sm-offset-3 col-xs-offset-3">
						<div class="row">
							<div class="ed_newsletter_section_form">
								<form class="form">
									<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
										<input class="form-control" type="text" placeholder="Newsletter Email" />
									</div>
									<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
										<button class="btn ed_btn ed_green">confirmer</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
        </div>
	</div>
</div>
<!--Newsletter Section six end-->
<!--Footer Top section start-->
<div class="ed_footer_wrapper">
	<div class="ed_footer_top">
		<div class="container">
			<div class="row">
				<div class="col-lg-4 col-md-4 col-sm-12">
					<div class="widget text-widget">
						<p><a href="index.html"><img src="images/footer/F_Logo.png" alt="Footer Logo" /></a></p>
						<p>Edution is an outstanding PSD template targeting educational institutions, helping them establish strong identity on the internet without any real developing knowledge.
						</p>
						<div class="ed_sociallink">
							<ul>
								<li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
								<li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Google+"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
								<li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
								<li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Linkedin"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
								<li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Whatsapp"><i class="fa fa-whatsapp" aria-hidden="true"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-12">
					<div class="widget text-widget">
						<h4 class="widget-title">find us</h4>
						<p><i class="fa fa-safari"></i>Wimbledon Street 42a, 45290 Wimbledon, <br/>United Kingdom</p>
						<p><i class="fa fa-envelope-o"></i><a href="#">info@edutioncollege.gov.co.uk</a> <a href="#">public@edutioncollege.gov.co.uk</a></p>
						<p><i class="fa fa-phone"></i> 1-220-090-080</p>
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-12">
					<div class="widget text-widget">
						<h4 class="widget-title"> media sociaux</h4>
						<p><strong>@education  </strong> How many students do you educate monthly? Open <a href=""> http://t.co/KFDdzLSD9</a><br/>2 days ago</p>
						
						<p><strong>@educationUK  </strong> Web Design that works. Have a look at this masterpiece. <a href="">http://t.co/9j8DH93zrO</a><br/>5 days ago</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--Footer Top section end-->
<!--Footer Bottom section start-->
<div class="ed_footer_bottom">
	<div class="container">
		<div class="col-lg-12 col-md-12 col-sm-12">
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
				<div class="ed_copy_right">
					<p>&copy; Copyright 2017, All Rights Reserved, <a href="#">EDUWakat</a></p>
				</div>
			</div>
			<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
				<div class="ed_footer_menu">
						<ul>
							<li><a href="<?php echo e(url('home')); ?>">Accueil</a></li>
							<li><a href="<?php echo e(url('private_policy')); ?>">Termes et conditions</a></li>
							<li><a href="<?php echo e(url('contact')); ?>">contactez-nous</a></li>
						</ul>
				</div>
			</div>
		</div>
		</div>
	</div>
</div>
<!--Footer Bottom section end-->
</div>
<!--Page main section end-->
<!--main js file start--> 
<script type="text/javascript" src="js/jquery-1.12.2.js"></script> 
<script type="text/javascript" src="js/bootstrap.js"></script> 
<script type="text/javascript" src="js/modernizr.js"></script> 
<script type="text/javascript" src="js/owl.carousel.js"></script>
<script type="text/javascript" src="js/smooth-scroll.js"></script> 
<script type="text/javascript" src="js/plugins/revel/jquery.themepunch.tools.min.js"></script>
<script type="text/javascript" src="js/plugins/revel/jquery.themepunch.revolution.min.js"></script>
<script type="text/javascript" src="js/plugins/revel/revolution.extension.layeranimation.min.js"></script>
<script type="text/javascript" src="js/plugins/revel/revolution.extension.navigation.min.js"></script>
<script type="text/javascript" src="js/plugins/revel/revolution.extension.slideanims.min.js"></script>
<script type="text/javascript" src="js/plugins/countto/jquery.countTo.js"></script>
<script type="text/javascript" src="js/plugins/countto/jquery.appear.js"></script>
<script type="text/javascript" src="js/custom.js"></script> 

<!--main js file end-->
</body>
</html>