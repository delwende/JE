<!--header end -->
<!--Breadcrumb start-->
<?php $__env->startSection('index_body'); ?>
<div class="ed_pagetitle">
<div class="ed_img_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-4 col-sm-6">
				<div class="page_title">
					<h2>Connectez-vous</h2>
				</div>
			</div>
			<div class="col-lg-6 col-md-8 col-sm-6">
				<ul class="breadcrumb">
					<li><a href="<?php echo e(url('home')); ?>">Accueil</a></li>
					<li><i class="fa fa-chevron-left"></i></li>
					<li><a href="#">Connectez-vous</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<!--Breadcrumb end-->
<div class="ed_transprentbg ed_toppadder80 ed_bottompadder80">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-lg-offset-3 col-md-offset-3">
				<div class="ed_teacher_div">
					<div class="ed_heading_top">
						<h3>Connectez-vous</h3>
					</div>
					<?php echo Form:: open(['route'=>'login','class'=>'ed_contact_form ed_toppadder40']); ?> 
						
						<div class="form-group <?php echo $errors->has('email')?'has-error':''; ?>">
							<?php echo Form::email('email', null,['class'=>'form-control','placeholder'=>'Email']); ?>

                            <?php echo $errors->first('email','<small class="help-block">:message</small>'); ?>

						</div>
						<div class="form-group <?php echo $errors->has('password')?'has-error':''; ?>">
							<?php echo Form::password('password',['class'=>'form-control', 'placeholder'=>'Mot de Passe']); ?>

                            <?php echo $errors->first('password','<small class="help-block">:message</small>'); ?>

						</div>
						<div class="form-control ">
                           <?php echo Form::label('rester' ,'Rester connecté'); ?>

                            <?php echo Form::checkbox('remember', old('remember')?'checked':'',['class'=>'checkbox']); ?>

                    </div>
                    <div>
                    <a href="<?php echo e(route('password.request')); ?>"> Mot de passe Oublié?</a>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <a href="<?php echo e(route('register')); ?>"> ouvrir un compte</a>
                    </div>
                    <div>
						<?php echo Form::submit('Envoyer',['class'=>'btn ed_btn ed_orange pull-right']); ?>

                    <?php echo Form::close(); ?>

                    </div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.login-template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>