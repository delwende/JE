<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Courses extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('courses', function (Blueprint $table) {
            $table->increments('id');
            $table->string('course_title');
            $table->integer('prof_id');
            $table->longText('description');
            $table->integer('review')->nullable();
            $table->string('price');
            $table->string('sale')->nullable();
            $table->string('duration');
            $table->string('course_image');
            $table->string('langue');
            $table->string('cat_id');
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('courses');
    }
}
